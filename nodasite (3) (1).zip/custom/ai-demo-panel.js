/* ============================================================
   NODA · ИИ-панель: логика демонстрационного блока.
   Локальная демонстрация на фиксированных данных: без обращения
   к модели, CRM и файловым сервисам. Состояние живёт в памяти
   компонента и сбрасывается перезагрузкой страницы.
   ============================================================ */
(function () {
  'use strict';

  var root = document.getElementById('aiDemoPanel');
  if (!root) return;

  var reduced = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;

  var YM_ID = 110366569;
  function track(name, params) {
    try {
      if (typeof window.ym === 'function') window.ym(YM_ID, 'reachGoal', name, params || {});
    } catch (e) { /* аналитика не должна ломать интерфейс */ }
  }

  var live = root.querySelector('.adp-srlive');
  function say(text) { if (live) live.textContent = text; }

  /* ============ вкладки панели ============ */
  var nav = root.querySelector('.adp-nav');
  var tabs = Array.prototype.slice.call(nav.querySelectorAll('[role="tab"]'));
  var panes = Array.prototype.slice.call(root.querySelectorAll('.adp-pane'));

  function navHorizontal() {
    return getComputedStyle(nav).flexDirection.indexOf('row') === 0;
  }
  function selectTab(tab, byUser) {
    tabs.forEach(function (t) {
      var on = t === tab;
      t.setAttribute('aria-selected', on ? 'true' : 'false');
      t.tabIndex = on ? 0 : -1;
    });
    panes.forEach(function (p) {
      p.hidden = p.id !== tab.getAttribute('aria-controls');
    });
    if (byUser) track('ai_demo_select', { scenario: tab.getAttribute('data-adp-tab') });
  }
  tabs.forEach(function (t) {
    t.addEventListener('click', function () { selectTab(t, true); });
  });
  nav.addEventListener('keydown', function (e) {
    var i = tabs.indexOf(document.activeElement);
    if (i < 0) return;
    var h = navHorizontal(), next = null;
    if ((h && e.key === 'ArrowRight') || (!h && e.key === 'ArrowDown')) next = tabs[(i + 1) % tabs.length];
    else if ((h && e.key === 'ArrowLeft') || (!h && e.key === 'ArrowUp')) next = tabs[(i - 1 + tabs.length) % tabs.length];
    else if (e.key === 'Home') next = tabs[0];
    else if (e.key === 'End') next = tabs[tabs.length - 1];
    if (next) { e.preventDefault(); next.focus(); selectTab(next, true); }
  });

  /* ============ вкладка «Ответы клиентам» ============ */
  var QA = {
    delivery: {
      q: 'За сколько дней доставите заказ?',
      a: '<b>2–3 рабочих дня</b> после комплектации заказа',
      plain: '2–3 рабочих дня после комплектации заказа',
      p: 'п. 3.2',
      src: '3.2. «Курьерская доставка занимает 2–3 рабочих дня после комплектации заказа».'
    },
    pickup: {
      q: 'Когда можно забрать заказ?',
      a: 'После уведомления о готовности заказа',
      plain: 'После уведомления о готовности заказа',
      p: 'п. 3.3',
      src: '3.3. «Самовывоз доступен после уведомления о готовности заказа».'
    },
    today: {
      q: 'Можно получить заказ сегодня?',
      a: 'В базе нет условия о доставке сегодня',
      plain: 'В базе нет условия о доставке сегодня',
      noans: true
    }
  };
  var qBtns = Array.prototype.slice.call(root.querySelectorAll('.adp-q'));
  var chatQ = root.querySelector('#adpChatQ');
  var botCard = root.querySelector('#adpBotCard');
  var ansEl = root.querySelector('#adpAns');
  var srcBtn = root.querySelector('#adpSrcBtn');
  var srcP = root.querySelector('#adpSrcP');
  var srcBody = root.querySelector('#adpSrcBody');
  var srcTxt = root.querySelector('#adpSrcTxt');
  var handWrap = root.querySelector('#adpHandWrap');
  var curKey = 'delivery';
  var waitTimer = null;

  function setSrcOpen(open) {
    srcBody.hidden = !open;
    srcBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
  }
  function renderAnswer() {
    var d = QA[curKey];
    botCard.classList.remove('adp-wait');
    botCard.classList.toggle('adp-noans', !!d.noans);
    ansEl.innerHTML = d.a;
    if (d.noans) {
      srcBtn.hidden = true;
      srcBody.hidden = true;
      handWrap.hidden = false;
      handWrap.innerHTML = '<button class="adp-btn-acc" type="button" id="adpHandBtn">Передать сотруднику</button>';
    } else {
      srcBtn.hidden = false;
      setSrcOpen(false);
      srcP.textContent = d.p;
      srcTxt.textContent = d.src;
      handWrap.hidden = true;
      handWrap.innerHTML = '';
    }
    say('Ответ: ' + d.plain);
  }
  function selectQuestion(key, byUser) {
    if (key === curKey) return;
    curKey = key;
    qBtns.forEach(function (b) {
      b.setAttribute('aria-pressed', b.getAttribute('data-q') === key ? 'true' : 'false');
    });
    chatQ.textContent = QA[key].q;
    setSrcOpen(false);
    if (waitTimer) { clearTimeout(waitTimer); waitTimer = null; }
    if (reduced) {
      renderAnswer();
    } else {
      botCard.classList.add('adp-wait');
      botCard.classList.remove('adp-noans');
      ansEl.textContent = 'Ищем ответ…';
      srcBtn.hidden = true;
      handWrap.hidden = true;
      waitTimer = setTimeout(function () { waitTimer = null; renderAnswer(); }, 300);
    }
    if (byUser) track('ai_demo_action', { scenario: 'support', action: 'question_' + key });
  }
  qBtns.forEach(function (b) {
    b.addEventListener('click', function () { selectQuestion(b.getAttribute('data-q'), true); });
  });
  srcBtn.addEventListener('click', function () {
    var open = srcBody.hidden;
    setSrcOpen(open);
    track('ai_demo_action', { scenario: 'support', action: open ? 'source_open' : 'source_close' });
  });
  root.addEventListener('click', function (e) {
    var hb = e.target.closest && e.target.closest('#adpHandBtn');
    if (!hb) return;
    handWrap.innerHTML = '<span class="adp-handmsg"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4.5 12.5l5 5L19.5 7"/></svg>Вопрос передан сотруднику</span>';
    say('Вопрос передан сотруднику');
    track('ai_demo_action', { scenario: 'support', action: 'handoff' });
  });

  /* ============ вкладка «Документы» ============ */
  var DOC = {
    payer: 'Компания «Пример»',
    sum: '48 000 ₽',
    num: '№104',
    date: '08.09.2026'
  };
  var dStep = 1;
  var daySel = null;       /* выбранный тип дней (шаг 2) */
  var dayConfirmed = null; /* подтверждённое значение */
  var stepBody = root.querySelector('#adpStepBody');
  var actRow = root.querySelector('#adpActRow');
  var docOpenBtn = root.querySelector('#adpDocOpen');
  var docSrc = root.querySelector('#adpDocSrc');

  function dayWord(t) { return t === 'cal' ? 'календарных' : 'рабочих'; }
  function termText() { return dayConfirmed ? '5 ' + dayWord(dayConfirmed) + ' дней' : '5 дней'; }

  docOpenBtn.addEventListener('click', function () {
    var open = docSrc.hidden;
    docSrc.hidden = !open;
    docOpenBtn.textContent = open ? 'Свернуть' : 'Открыть';
    docOpenBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
    track('ai_demo_action', { scenario: 'documents', action: open ? 'source_open' : 'source_close' });
  });
  function closeDocSrc() {
    docSrc.hidden = true;
    docOpenBtn.textContent = 'Открыть';
    docOpenBtn.setAttribute('aria-expanded', 'false');
  }

  function fieldsHTML() {
    var term = dayConfirmed
      ? '<b>' + termText() + ' <span class="adp-badge-ok">Уточнено вами</span></b>'
      : '<b>5 дней</b><span class="adp-field-note">Нужно уточнить тип дней</span>';
    return '<div class="adp-fields">' +
      '<div class="adp-field"><i>Плательщик</i><b>' + DOC.payer + '</b></div>' +
      '<div class="adp-field"><i>Сумма</i><b class="adp-sum">' + DOC.sum + '</b></div>' +
      '<div class="adp-field"><i>Срок оплаты</i>' + term + '</div>' +
    '</div>';
  }
  var BACK_SVG = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M19 12H5M11 6l-6 6 6 6"/></svg>';

  function renderDocStep(focusHint) {
    if (dStep === 1) {
      stepBody.innerHTML = fieldsHTML();
      actRow.innerHTML = '<button class="adp-btn-acc" type="button" id="adpDocAct">Уточнить срок</button>';
    } else if (dStep === 2) {
      stepBody.innerHTML =
        '<p class="adp-daysq">Какие дни подтвердил сотрудник?</p>' +
        '<div class="adp-dayrow" role="group" aria-label="Тип дней">' +
          '<button class="adp-day" type="button" data-day="cal" aria-pressed="' + (daySel === 'cal') + '">Календарные</button>' +
          '<button class="adp-day" type="button" data-day="work" aria-pressed="' + (daySel === 'work') + '">Рабочие</button>' +
        '</div>';
      actRow.innerHTML = '<button class="adp-back" type="button" id="adpBack">' + BACK_SVG + 'Назад</button>';
    } else if (dStep === 3) {
      stepBody.innerHTML = fieldsHTML();
      actRow.innerHTML =
        '<button class="adp-back" type="button" id="adpBack">' + BACK_SVG + 'Назад</button>' +
        '<button class="adp-btn-acc" type="button" id="adpDocAct">Сформировать строку</button>';
    } else {
      stepBody.innerHTML =
        '<p class="adp-tablecap">Строка готова к переносу</p>' +
        '<div class="adp-table">' +
          '<div class="adp-trow adp-trow-head" aria-hidden="true"><span>Документ</span><span>Дата</span><span>Плательщик</span><span>Сумма</span><span>Срок</span></div>' +
          '<div class="adp-trow">' +
            '<span data-l="Документ">' + DOC.num + '</span>' +
            '<span data-l="Дата">' + DOC.date + '</span>' +
            '<span data-l="Плательщик">' + DOC.payer + '</span>' +
            '<span data-l="Сумма">' + DOC.sum + '</span>' +
            '<span data-l="Срок">' + termText() + '</span>' +
          '</div>' +
        '</div>';
      actRow.innerHTML = '<button class="adp-back" type="button" id="adpBack">' + BACK_SVG + 'Назад</button>';
    }
    /* фокус: после «Назад» — на основное действие предыдущего шага,
       при возврате к уточнению — на ранее выбранный тип дней */
    if (focusHint === 'back') {
      var target = null;
      if (dStep === 2) {
        target = stepBody.querySelector('.adp-day[aria-pressed="true"]') || stepBody.querySelector('.adp-day');
      } else {
        target = actRow.querySelector('#adpDocAct') || actRow.querySelector('#adpBack');
      }
      if (target) target.focus();
    } else if (focusHint === 'fwd') {
      var t2 = null;
      if (dStep === 2) t2 = stepBody.querySelector('.adp-day[aria-pressed="true"]') || stepBody.querySelector('.adp-day');
      else t2 = actRow.querySelector('#adpDocAct') || actRow.querySelector('#adpBack');
      if (t2) t2.focus();
    }
  }
  function goDocStep(n, focusHint) {
    dStep = n;
    closeDocSrc();
    renderDocStep(focusHint);
  }
  root.querySelector('#adpPaneDocs').addEventListener('click', function (e) {
    var act = e.target.closest && e.target.closest('#adpDocAct');
    if (act) {
      if (dStep === 1) {
        goDocStep(2, 'fwd');
        say('Шаг 2: уточнение срока');
      } else if (dStep === 3) {
        goDocStep(4, 'fwd');
        say('Строка готова к переносу: срок ' + termText());
        track('ai_demo_action', { scenario: 'documents', action: 'row_ready' });
      }
      return;
    }
    var day = e.target.closest && e.target.closest('.adp-day');
    if (day) {
      daySel = day.getAttribute('data-day');
      dayConfirmed = daySel;
      goDocStep(3, 'fwd');
      say('Срок уточнён: ' + termText());
      track('ai_demo_action', { scenario: 'documents', action: 'days_' + daySel });
      return;
    }
    var back = e.target.closest && e.target.closest('#adpBack');
    if (back) {
      goDocStep(dStep - 1, 'back');
      say('Возврат на предыдущий шаг');
      track('ai_demo_action', { scenario: 'documents', action: 'back_to_' + dStep });
    }
  });

  /* ============ вкладка «Действия в CRM» ============ */
  var phase = 'plan';
  var crmH = root.querySelector('#adpCrmH');
  var planCard = root.querySelector('#adpPlanCard');
  var resultCard = root.querySelector('#adpResult');
  var planDeal = root.querySelector('#adpPlanDeal');
  var planTask = root.querySelector('#adpPlanTask');
  var editWrap = root.querySelector('#adpEdit');
  var editBtn = root.querySelector('#adpEditBtn');
  var confirmBtn = root.querySelector('#adpConfirmBtn');
  var counter = root.querySelector('#adpCounter');
  var editErr = root.querySelector('#adpEditErr');
  var fDeal = root.querySelector('#adpFDeal');
  var fTask = root.querySelector('#adpFTask');
  var detailsBtn = root.querySelector('#adpDetailsBtn');
  var detailsBox = root.querySelector('#adpDetails');
  var journalBox = root.querySelector('#adpJournal');
  var crmTimers = [];

  detailsBtn.addEventListener('click', function () {
    var box = phase === 'done' ? journalBox : detailsBox;
    var open = box.hidden;
    box.hidden = !open;
    detailsBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
    track('ai_demo_action', { scenario: 'actions', action: (phase === 'done' ? 'journal_' : 'details_') + (open ? 'open' : 'close') });
  });

  editBtn.addEventListener('click', function () {
    if (phase !== 'plan') return;
    var open = editWrap.hidden;
    editWrap.hidden = !open;
    editBtn.textContent = open ? 'Свернуть' : 'Изменить';
    editBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
    if (open) fDeal.focus();
  });
  function syncPlan() {
    planDeal.textContent = fDeal.value.trim() === '' ? '—' : fDeal.value;
    planTask.textContent = fTask.value.trim() === '' ? '—' : fTask.value;
    editErr.classList.remove('adp-show');
  }
  fDeal.addEventListener('input', syncPlan);
  fTask.addEventListener('input', syncPlan);

  confirmBtn.addEventListener('click', function () {
    if (phase !== 'plan') return;
    var d = fDeal.value.trim(), t = fTask.value.trim();
    if (d === '' || t === '') {
      if (editWrap.hidden) {
        editWrap.hidden = false;
        editBtn.textContent = 'Свернуть';
        editBtn.setAttribute('aria-expanded', 'true');
      }
      editErr.classList.add('adp-show');
      say('Заполните оба поля');
      (d === '' ? fDeal : fTask).focus();
      return;
    }
    phase = 'running';
    confirmBtn.disabled = true;
    confirmBtn.textContent = 'Выполняем…';
    counter.textContent = '0 из 3 выполнено';
    editBtn.disabled = true;
    fDeal.disabled = true;
    fTask.disabled = true;
    editWrap.hidden = true;
    editBtn.textContent = 'Изменить';
    editBtn.setAttribute('aria-expanded', 'false');
    track('ai_demo_action', { scenario: 'actions', action: 'confirm' });
    var rows = Array.prototype.slice.call(planCard.querySelectorAll('.adp-plan-row'));
    var stepMs = reduced ? 0 : 360;
    rows.forEach(function (row, i) {
      crmTimers.push(setTimeout(function () {
        row.classList.add('adp-done');
        counter.textContent = (i + 1) + ' из 3 выполнено';
        say('Выполнено ' + (i + 1) + ' из 3');
        if (i === rows.length - 1) {
          crmTimers.push(setTimeout(finishCrm, reduced ? 0 : 420));
        }
      }, stepMs * (i + 1)));
    });
  });

  function finishCrm() {
    phase = 'done';
    crmH.textContent = 'Заявка уже в работе';
    planCard.hidden = true;
    resultCard.hidden = false;
    root.querySelector('#adpResDeal').textContent = fDeal.value.trim();
    root.querySelector('#adpResTask').textContent = fTask.value.trim() + ' · исполнитель — менеджер';
    root.querySelector('#adpJDeal').textContent = 'Сделка создана #D-104 — ' + fDeal.value.trim();
    detailsBox.hidden = true;
    journalBox.hidden = true;
    detailsBtn.textContent = 'Журнал действий';
    detailsBtn.setAttribute('aria-controls', 'adpJournal');
    detailsBtn.setAttribute('aria-expanded', 'false');
    say('Готово: сделка создана, задача назначена');
    track('ai_demo_action', { scenario: 'actions', action: 'done' });
  }
})();
