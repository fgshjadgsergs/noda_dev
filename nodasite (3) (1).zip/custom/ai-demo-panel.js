/* ============================================================
   NODA · ИИ-панель: логика демонстрационного блока.
   Локальная демонстрация на фиксированных данных: без обращения
   к модели, CRM и файловым сервисам. Состояние живёт в памяти
   компонента и сбрасывается перезагрузкой страницы.
   ============================================================ */
(function () {
  'use strict';

  var root = document.getElementById('aiDemoPanel');
  if (!root) return;

  var reduced = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var EN = document.documentElement.lang === 'en';

  var YM_ID = 110366569;
  function track(name, params) {
    try {
      if (typeof window.ym === 'function') window.ym(YM_ID, 'reachGoal', name, params || {});
    } catch (e) { /* аналитика не должна ломать интерфейс */ }
  }

  var live = root.querySelector('.adp-srlive');
  function say(text) { if (live) live.textContent = text; }

  /* ============ вкладки панели ============ */
  var nav = root.querySelector('.adp-nav');
  var tabs = Array.prototype.slice.call(nav.querySelectorAll('[role="tab"]'));
  var panes = Array.prototype.slice.call(root.querySelectorAll('.adp-pane'));

  function navHorizontal() {
    return getComputedStyle(nav).flexDirection.indexOf('row') === 0;
  }
  function selectTab(tab, byUser) {
    tabs.forEach(function (t) {
      var on = t === tab;
      t.setAttribute('aria-selected', on ? 'true' : 'false');
      t.tabIndex = on ? 0 : -1;
    });
    panes.forEach(function (p) {
      p.hidden = p.id !== tab.getAttribute('aria-controls');
    });
    if (byUser) track('ai_demo_select', { scenario: tab.getAttribute('data-adp-tab') });
  }
  tabs.forEach(function (t) {
    t.addEventListener('click', function () { selectTab(t, true); });
  });
  nav.addEventListener('keydown', function (e) {
    var i = tabs.indexOf(document.activeElement);
    if (i < 0) return;
    var h = navHorizontal(), next = null;
    if ((h && e.key === 'ArrowRight') || (!h && e.key === 'ArrowDown')) next = tabs[(i + 1) % tabs.length];
    else if ((h && e.key === 'ArrowLeft') || (!h && e.key === 'ArrowUp')) next = tabs[(i - 1 + tabs.length) % tabs.length];
    else if (e.key === 'Home') next = tabs[0];
    else if (e.key === 'End') next = tabs[tabs.length - 1];
    if (next) { e.preventDefault(); next.focus(); selectTab(next, true); }
  });

  /* ============ вкладка «Ответы клиентам»: учебный чат ============
     Клиент сам выбирает вопрос (кнопки в ленте или свободный ввод),
     ассистент отвечает по учебным документам. Повторно задать один
     и тот же вопрос нельзя; когда вопросы закончились — переход к
     настоящей заявке. Никаких сетевых запросов и моделей. */
  var BOT_AVA = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="4" y="7" width="16" height="12" rx="3.5"/><path d="M12 7V4M8.5 4h7"/><circle cx="9.2" cy="12.6" r="1.1" fill="currentColor" stroke="none"/><circle cx="14.8" cy="12.6" r="1.1" fill="currentColor" stroke="none"/><path d="M9.5 16h5"/></svg>';
  var CH = EN ? {
    qrCap: 'Pick a question — I answer using the company documents:',
    more: 'What else would you like to know?',
    done: 'That is every question I have prepared. On a pilot I answer using your own documents — shall we discuss it?',
    cta: 'Discuss a project',
    asked: 'I have already answered that one above ↑ Pick another question.',
    unknown: 'In this demo I answer only from the training documents. Pick a question from the list below.',
    src: 'Answer source', hand: 'Hand over to a person', handed: 'The question was handed over to a person',
    answered: 'Answered', of: 'of', answer: 'Answer: '
  } : {
    qrCap: 'Выберите вопрос — отвечу по документам компании:',
    more: 'Что ещё подсказать?',
    done: 'Это все вопросы, которые я подготовил. На пилоте отвечу по вашим документам — обсудим?',
    cta: 'Обсудить проект',
    asked: 'На этот вопрос я уже ответил выше ↑ Выберите другой.',
    unknown: 'В демо я отвечаю только по учебным документам. Выберите вопрос из списка ниже.',
    src: 'Источник ответа', hand: 'Передать сотруднику', handed: 'Вопрос передан сотруднику',
    answered: 'Отвечено', of: 'из', answer: 'Ответ: '
  };
  var QA = EN ? {
    delivery: { q: 'How many days does delivery take?', a: '<b>2–3 business days</b> after the order is assembled', plain: '2–3 business days after the order is assembled', doc: 'Delivery terms', p: 'cl. 3.2', src: '3.2. “Courier delivery takes 2–3 business days after the order is assembled.”', kw: /deliver|ship|days|long/i },
    pickup: { q: 'When can I pick up my order?', a: 'After you are notified that the order is ready', plain: 'After you are notified that the order is ready', doc: 'Delivery terms', p: 'cl. 3.3', src: '3.3. “Self-pickup is available after the customer is notified that the order is ready.”', kw: /pick|collect|ready/i },
    payment: { q: 'How can I pay for the order?', a: 'By card online or in cash on delivery', plain: 'By card online or in cash on delivery', doc: 'Payment terms', p: 'cl. 4.1', src: '4.1. “The order can be paid by card online or in cash on delivery.”', kw: /pay|card|cash|price/i },
    today: { q: 'Can I get the order today?', a: 'The knowledge base has no same-day delivery terms', plain: 'The knowledge base has no same-day delivery terms', noans: true, kw: /today|now|urgent|same/i }
  } : {
    delivery: { q: 'За сколько дней доставите заказ?', a: '<b>2–3 рабочих дня</b> после комплектации заказа', plain: '2–3 рабочих дня после комплектации заказа', doc: 'Условия доставки', p: 'п. 3.2', src: '3.2. «Курьерская доставка занимает 2–3 рабочих дня после комплектации заказа».', kw: /доставк|сколько дн|срок|привез/i },
    pickup: { q: 'Когда можно забрать заказ?', a: 'После уведомления о готовности заказа', plain: 'После уведомления о готовности заказа', doc: 'Условия доставки', p: 'п. 3.3', src: '3.3. «Самовывоз доступен после уведомления о готовности заказа».', kw: /забрать|самовывоз|заехать|готов/i },
    payment: { q: 'Как можно оплатить заказ?', a: 'Картой онлайн или наличными при получении', plain: 'Картой онлайн или наличными при получении', doc: 'Условия оплаты', p: 'п. 4.1', src: '4.1. «Заказ можно оплатить картой онлайн или наличными при получении».', kw: /оплат|плат|карт|наличн|цена|стоим/i },
    today: { q: 'Можно получить заказ сегодня?', a: 'В базе нет условия о доставке сегодня', plain: 'В базе нет условия о доставке сегодня', noans: true, kw: /сегодня|сейчас|срочно|прямо/i }
  };
  var ORDER = ['delivery', 'pickup', 'payment', 'today'];
  var feed = root.querySelector('#adpFeed');
  var qrMsg = root.querySelector('#adpQr');
  var countEl = root.querySelector('#adpCount');
  var cwForm = root.querySelector('#adpCwForm');
  var cwInp = root.querySelector('#adpInp');
  var asked = {}, askedN = 0, busy = false, srcSeq = 0;

  function feedScroll() {
    feed.scrollTo({ top: feed.scrollHeight, behavior: reduced ? 'auto' : 'smooth' });
  }
  function addUserMsg(text) {
    var m = document.createElement('div');
    m.className = 'adp-msg adp-m-user';
    m.textContent = text;
    feed.appendChild(m);
    feedScroll();
  }
  function botShell(extraClass) {
    var m = document.createElement('div');
    m.className = 'adp-msg adp-m-bot' + (extraClass ? ' ' + extraClass : '');
    m.innerHTML = '<span class="adp-m-ava" aria-hidden="true">' + BOT_AVA + '</span><div class="adp-m-card"></div>';
    feed.appendChild(m);
    return m.querySelector('.adp-m-card');
  }
  function botText(text) {
    var card = botShell('');
    card.textContent = text;
    feedScroll();
  }
  function addTyping() {
    var card = botShell('adp-typing');
    card.innerHTML = '<span class="adp-t-dots" aria-hidden="true"><i></i><i></i><i></i></span>';
    card.parentNode.setAttribute('data-typing', '1');
    feedScroll();
    return card.parentNode;
  }
  function withTyping(fn) {
    if (reduced) { fn(); return; }
    busy = true;
    var t = addTyping();
    setTimeout(function () { t.remove(); busy = false; fn(); }, 520);
  }
  function addBotAnswer(key) {
    var d = QA[key];
    var card = botShell(d.noans ? 'adp-m-amber' : '');
    var html = '<p class="adp-ans">' + d.a + '</p>';
    if (d.noans) {
      html += '<button class="adp-btn-acc adp-hand" type="button">' + CH.hand + '</button>';
    } else {
      var id = 'adpSrc-' + (++srcSeq);
      html += '<button class="adp-src" type="button" aria-expanded="false" aria-controls="' + id + '">' + CH.src + ' <i class="adp-src-p">' + d.p + '</i> <span class="adp-ch" aria-hidden="true">▾</span></button>' +
        '<div class="adp-srcbody" id="' + id + '" hidden><b>' + d.doc + '</b><p>' + d.src + '</p></div>';
    }
    card.innerHTML = html;
    feedScroll();
    say(CH.answer + d.plain);
  }
  function updateCount() {
    if (countEl) countEl.textContent = CH.answered + ' ' + askedN + ' ' + CH.of + ' ' + ORDER.length;
  }
  /* блок быстрых ответов всегда в конце ленты; заданные вопросы отключены */
  function renderQr() {
    if (!qrMsg) return;
    var cap = qrMsg.querySelector('.adp-qr-cap');
    var wrap = qrMsg.querySelector('.adp-qr');
    if (askedN >= ORDER.length) {
      qrMsg.remove();
      qrMsg = null;
      var card = botShell('');
      card.innerHTML = '<p>' + CH.done + '</p><a class="adp-cta" href="#contact">' + CH.cta + ' <span aria-hidden="true">↗</span></a>';
      if (cwInp) { cwInp.disabled = true; cwInp.placeholder = EN ? 'All demo questions answered' : 'Все вопросы демо отвечены'; }
      feedScroll();
      return;
    }
    if (cap) cap.textContent = askedN ? CH.more : CH.qrCap;
    wrap.querySelectorAll('.adp-q').forEach(function (b) {
      var k = b.getAttribute('data-q');
      b.disabled = !!asked[k];
      b.setAttribute('aria-pressed', asked[k] ? 'true' : 'false');
    });
    feed.appendChild(qrMsg);
    feedScroll();
  }
  function ask(key, viaText) {
    if (busy || !QA[key] || asked[key]) return;
    asked[key] = 1;
    askedN++;
    updateCount();
    if (!viaText) addUserMsg(QA[key].q);
    withTyping(function () {
      addBotAnswer(key);
      renderQr();
    });
    track('ai_demo_action', { scenario: 'support', action: 'question_' + key });
  }
  feed.addEventListener('click', function (e) {
    var qb = e.target.closest && e.target.closest('.adp-q');
    if (qb) { ask(qb.getAttribute('data-q'), false); return; }
    var sb = e.target.closest && e.target.closest('.adp-src');
    if (sb) {
      var body = document.getElementById(sb.getAttribute('aria-controls'));
      var open = body.hidden;
      body.hidden = !open;
      sb.setAttribute('aria-expanded', open ? 'true' : 'false');
      if (open) feedScroll();
      track('ai_demo_action', { scenario: 'support', action: open ? 'source_open' : 'source_close' });
      return;
    }
    var hb = e.target.closest && e.target.closest('.adp-hand');
    if (hb) {
      var wrap = document.createElement('span');
      wrap.className = 'adp-handmsg';
      wrap.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4.5 12.5l5 5L19.5 7"/></svg>' + CH.handed;
      hb.parentNode.replaceChild(wrap, hb);
      say(CH.handed);
      track('ai_demo_action', { scenario: 'support', action: 'handoff' });
    }
  });
  /* свободный ввод: распознаём тему по ключевым словам */
  if (cwForm && cwInp) {
    cwForm.addEventListener('submit', function (e) {
      e.preventDefault();
      var text = cwInp.value.replace(/\s+/g, ' ').trim();
      if (!text || busy) return;
      cwInp.value = '';
      addUserMsg(text);
      var hit = null;
      for (var i = 0; i < ORDER.length; i++) {
        if (QA[ORDER[i]].kw.test(text)) { hit = ORDER[i]; break; }
      }
      if (hit && !asked[hit]) {
        ask(hit, true);
      } else {
        withTyping(function () {
          botText(hit ? CH.asked : CH.unknown);
          renderQr();
        });
        track('ai_demo_action', { scenario: 'support', action: hit ? 'repeat' : 'free_text' });
      }
    });
  }
  updateCount();

  /* ============ вкладка «Документы» ============ */
  var DOC = EN ? {
    payer: 'Sample Company LLC',
    sum: '48 000 ₽',
    num: '#104',
    date: '08.09.2026'
  } : {
    payer: 'Компания «Пример»',
    sum: '48 000 ₽',
    num: '№104',
    date: '08.09.2026'
  };
  var dStep = 1;
  var daySel = null;       /* выбранный тип дней (шаг 2) */
  var dayConfirmed = null; /* подтверждённое значение */
  var stepBody = root.querySelector('#adpStepBody');
  var actRow = root.querySelector('#adpActRow');
  var docOpenBtn = root.querySelector('#adpDocOpen');
  var docSrc = root.querySelector('#adpDocSrc');

  function dayWord(t) { return EN ? (t === 'cal' ? 'calendar' : 'business') : (t === 'cal' ? 'календарных' : 'рабочих'); }
  function termText() { return dayConfirmed ? '5 ' + dayWord(dayConfirmed) + (EN ? ' days' : ' дней') : (EN ? '5 days' : '5 дней'); }

  docOpenBtn.addEventListener('click', function () {
    var open = docSrc.hidden;
    docSrc.hidden = !open;
    docOpenBtn.textContent = open ? (EN ? 'Collapse' : 'Свернуть') : (EN ? 'Open' : 'Открыть');
    docOpenBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
    track('ai_demo_action', { scenario: 'documents', action: open ? 'source_open' : 'source_close' });
  });
  function closeDocSrc() {
    docSrc.hidden = true;
    docOpenBtn.textContent = EN ? 'Open' : 'Открыть';
    docOpenBtn.setAttribute('aria-expanded', 'false');
  }

  function fieldsHTML() {
    var term = dayConfirmed
      ? '<b>' + termText() + ' <span class="adp-badge-ok">' + (EN ? 'Confirmed by you' : 'Уточнено вами') + '</span></b>'
      : '<b>' + (EN ? '5 days' : '5 дней') + '</b><span class="adp-field-note">' + (EN ? 'Day type needs confirmation' : 'Нужно уточнить тип дней') + '</span>';
    return '<div class="adp-fields">' +
      '<div class="adp-field"><i>' + (EN ? 'Payer' : 'Плательщик') + '</i><b>' + DOC.payer + '</b></div>' +
      '<div class="adp-field"><i>' + (EN ? 'Amount' : 'Сумма') + '</i><b class="adp-sum">' + DOC.sum + '</b></div>' +
      '<div class="adp-field"><i>' + (EN ? 'Payment term' : 'Срок оплаты') + '</i>' + term + '</div>' +
    '</div>';
  }
  var BACK_SVG = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M19 12H5M11 6l-6 6 6 6"/></svg>';

  function renderDocStep(focusHint) {
    if (dStep === 1) {
      stepBody.innerHTML = fieldsHTML();
      actRow.innerHTML = '<button class="adp-btn-acc" type="button" id="adpDocAct">' + (EN ? 'Confirm the term' : 'Уточнить срок') + '</button>';
    } else if (dStep === 2) {
      stepBody.innerHTML =
        '<p class="adp-daysq">' + (EN ? 'Which day type did the employee confirm?' : 'Какие дни подтвердил сотрудник?') + '</p>' +
        '<div class="adp-dayrow" role="group" aria-label="Тип дней">' +
          '<button class="adp-day" type="button" data-day="cal" aria-pressed="' + (daySel === 'cal') + '">' + (EN ? 'Calendar' : 'Календарные') + '</button>' +
          '<button class="adp-day" type="button" data-day="work" aria-pressed="' + (daySel === 'work') + '">' + (EN ? 'Business' : 'Рабочие') + '</button>' +
        '</div>';
      actRow.innerHTML = '<button class="adp-back" type="button" id="adpBack">' + BACK_SVG + (EN ? 'Back' : 'Назад') + '</button>';
    } else if (dStep === 3) {
      stepBody.innerHTML = fieldsHTML();
      actRow.innerHTML =
        '<button class="adp-back" type="button" id="adpBack">' + BACK_SVG + (EN ? 'Back' : 'Назад') + '</button>' +
        '<button class="adp-btn-acc" type="button" id="adpDocAct">' + (EN ? 'Build the row' : 'Сформировать строку') + '</button>';
    } else {
      stepBody.innerHTML =
        '<p class="adp-tablecap">' + (EN ? 'The row is ready to transfer' : 'Строка готова к переносу') + '</p>' +
        '<div class="adp-table">' +
          '<div class="adp-trow adp-trow-head" aria-hidden="true"><span>' + (EN ? 'Document' : 'Документ') + '</span><span>' + (EN ? 'Date' : 'Дата') + '</span><span>' + (EN ? 'Payer' : 'Плательщик') + '</span><span>' + (EN ? 'Amount' : 'Сумма') + '</span><span>' + (EN ? 'Term' : 'Срок') + '</span></div>' +
          '<div class="adp-trow">' +
            '<span data-l="' + (EN ? 'Document' : 'Документ') + '">' + DOC.num + '</span>' +
            '<span data-l="' + (EN ? 'Date' : 'Дата') + '">' + DOC.date + '</span>' +
            '<span data-l="' + (EN ? 'Payer' : 'Плательщик') + '">' + DOC.payer + '</span>' +
            '<span data-l="' + (EN ? 'Amount' : 'Сумма') + '">' + DOC.sum + '</span>' +
            '<span data-l="' + (EN ? 'Term' : 'Срок') + '">' + termText() + '</span>' +
          '</div>' +
        '</div>';
      actRow.innerHTML = '<button class="adp-back" type="button" id="adpBack">' + BACK_SVG + (EN ? 'Back' : 'Назад') + '</button>';
    }
    /* фокус: после «Назад» — на основное действие предыдущего шага,
       при возврате к уточнению — на ранее выбранный тип дней */
    if (focusHint === 'back') {
      var target = null;
      if (dStep === 2) {
        target = stepBody.querySelector('.adp-day[aria-pressed="true"]') || stepBody.querySelector('.adp-day');
      } else {
        target = actRow.querySelector('#adpDocAct') || actRow.querySelector('#adpBack');
      }
      if (target) target.focus();
    } else if (focusHint === 'fwd') {
      var t2 = null;
      if (dStep === 2) t2 = stepBody.querySelector('.adp-day[aria-pressed="true"]') || stepBody.querySelector('.adp-day');
      else t2 = actRow.querySelector('#adpDocAct') || actRow.querySelector('#adpBack');
      if (t2) t2.focus();
    }
  }
  function goDocStep(n, focusHint) {
    dStep = n;
    closeDocSrc();
    renderDocStep(focusHint);
  }
  root.querySelector('#adpPaneDocs').addEventListener('click', function (e) {
    var act = e.target.closest && e.target.closest('#adpDocAct');
    if (act) {
      if (dStep === 1) {
        goDocStep(2, 'fwd');
        say(EN ? 'Step 2: confirm the term' : 'Шаг 2: уточнение срока');
      } else if (dStep === 3) {
        goDocStep(4, 'fwd');
        say((EN ? 'Row ready, term ' : 'Строка готова к переносу: срок ') + termText());
        track('ai_demo_action', { scenario: 'documents', action: 'row_ready' });
      }
      return;
    }
    var day = e.target.closest && e.target.closest('.adp-day');
    if (day) {
      daySel = day.getAttribute('data-day');
      dayConfirmed = daySel;
      goDocStep(3, 'fwd');
      say((EN ? 'Term confirmed: ' : 'Срок уточнён: ') + termText());
      track('ai_demo_action', { scenario: 'documents', action: 'days_' + daySel });
      return;
    }
    var back = e.target.closest && e.target.closest('#adpBack');
    if (back) {
      goDocStep(dStep - 1, 'back');
      say(EN ? 'Back to the previous step' : 'Возврат на предыдущий шаг');
      track('ai_demo_action', { scenario: 'documents', action: 'back_to_' + dStep });
    }
  });

  /* ============ вкладка «Действия в CRM» ============ */
  var phase = 'plan';
  var crmH = root.querySelector('#adpCrmH');
  var planCard = root.querySelector('#adpPlanCard');
  var resultCard = root.querySelector('#adpResult');
  var planDeal = root.querySelector('#adpPlanDeal');
  var planTask = root.querySelector('#adpPlanTask');
  var editWrap = root.querySelector('#adpEdit');
  var editBtn = root.querySelector('#adpEditBtn');
  var confirmBtn = root.querySelector('#adpConfirmBtn');
  var counter = root.querySelector('#adpCounter');
  var editErr = root.querySelector('#adpEditErr');
  var fDeal = root.querySelector('#adpFDeal');
  var fTask = root.querySelector('#adpFTask');
  var detailsBtn = root.querySelector('#adpDetailsBtn');
  var detailsBox = root.querySelector('#adpDetails');
  var journalBox = root.querySelector('#adpJournal');
  var crmTimers = [];

  detailsBtn.addEventListener('click', function () {
    var box = phase === 'done' ? journalBox : detailsBox;
    var open = box.hidden;
    box.hidden = !open;
    detailsBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
    track('ai_demo_action', { scenario: 'actions', action: (phase === 'done' ? 'journal_' : 'details_') + (open ? 'open' : 'close') });
  });

  editBtn.addEventListener('click', function () {
    if (phase !== 'plan') return;
    var open = editWrap.hidden;
    editWrap.hidden = !open;
    editBtn.textContent = open ? (EN ? 'Collapse' : 'Свернуть') : (EN ? 'Edit' : 'Изменить');
    editBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
    if (open) fDeal.focus();
  });
  function syncPlan() {
    planDeal.textContent = fDeal.value.trim() === '' ? '—' : fDeal.value;
    planTask.textContent = fTask.value.trim() === '' ? '—' : fTask.value;
    editErr.classList.remove('adp-show');
  }
  fDeal.addEventListener('input', syncPlan);
  fTask.addEventListener('input', syncPlan);

  confirmBtn.addEventListener('click', function () {
    if (phase !== 'plan') return;
    var d = fDeal.value.trim(), t = fTask.value.trim();
    if (d === '' || t === '') {
      if (editWrap.hidden) {
        editWrap.hidden = false;
        editBtn.textContent = 'Свернуть';
        editBtn.setAttribute('aria-expanded', 'true');
      }
      editErr.classList.add('adp-show');
      say(EN ? 'Fill in both fields' : 'Заполните оба поля');
      (d === '' ? fDeal : fTask).focus();
      return;
    }
    phase = 'running';
    confirmBtn.disabled = true;
    confirmBtn.textContent = EN ? 'Running…' : 'Выполняем…';
    counter.textContent = EN ? '0 of 3 done' : '0 из 3 выполнено';
    editBtn.disabled = true;
    fDeal.disabled = true;
    fTask.disabled = true;
    editWrap.hidden = true;
    editBtn.textContent = EN ? 'Edit' : 'Изменить';
    editBtn.setAttribute('aria-expanded', 'false');
    track('ai_demo_action', { scenario: 'actions', action: 'confirm' });
    var rows = Array.prototype.slice.call(planCard.querySelectorAll('.adp-plan-row'));
    var stepMs = reduced ? 0 : 360;
    rows.forEach(function (row, i) {
      crmTimers.push(setTimeout(function () {
        row.classList.add('adp-done');
        counter.textContent = (i + 1) + (EN ? ' of 3 done' : ' из 3 выполнено');
        say(EN ? ((i + 1) + ' of 3 done') : ('Выполнено ' + (i + 1) + ' из 3'));
        if (i === rows.length - 1) {
          crmTimers.push(setTimeout(finishCrm, reduced ? 0 : 420));
        }
      }, stepMs * (i + 1)));
    });
  });

  function finishCrm() {
    phase = 'done';
    crmH.textContent = EN ? 'The request is in progress' : 'Заявка уже в работе';
    planCard.hidden = true;
    resultCard.hidden = false;
    root.querySelector('#adpResDeal').textContent = fDeal.value.trim();
    root.querySelector('#adpResTask').textContent = fTask.value.trim() + (EN ? ' · assignee — manager' : ' · исполнитель — менеджер');
    root.querySelector('#adpJDeal').textContent = (EN ? 'Deal created #D-104 — ' : 'Сделка создана #D-104 — ') + fDeal.value.trim();
    detailsBox.hidden = true;
    journalBox.hidden = true;
    detailsBtn.textContent = EN ? 'Action log' : 'Журнал действий';
    detailsBtn.setAttribute('aria-controls', 'adpJournal');
    detailsBtn.setAttribute('aria-expanded', 'false');
    say(EN ? 'Done: deal created, task assigned' : 'Готово: сделка создана, задача назначена');
    track('ai_demo_action', { scenario: 'actions', action: 'done' });
  }
})();
