/* ============================================================
   NODA · Логика новых блоков страницы «Сайты и приложения»
   (B1 демо, B2 форматы, B3 этапы, B4 форма, F1 футер).
   Подключается только на этой странице; ванильный JS без
   библиотек. Демо-примеры работают локально и никуда не
   отправляют данные; настоящая заявка уходит POST в /mail.php.
   ============================================================ */
(function () {
  'use strict';

  var reducedMotion = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ---------- аналитика: единый адаптер (Яндекс Метрика) ---------- */
  var YM_ID = 110366569;
  function track(name, params) {
    try {
      if (typeof window.ym === 'function') window.ym(YM_ID, 'reachGoal', name, params || {});
    } catch (e) { /* аналитика не должна ломать интерфейс */ }
  }

  /* ---------- плавная прокрутка к якорям ---------- */
  if (!reducedMotion) document.documentElement.style.scrollBehavior = 'smooth';

  /* ---------- фон шапки при прокрутке ---------- */
  var navEl = document.getElementById('nav');
  if (navEl) {
    var onScroll = function () { navEl.classList.toggle('scrolled', window.scrollY > 8); };
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
  }

  /* ---------- мобильное меню (бургер) ---------- */
  var burger = document.querySelector('.nav-burger');
  function closeMenu() {
    document.body.classList.remove('menu-open');
    var nav = document.getElementById('nav');
    if (nav) nav.classList.remove('menu-open');
    if (burger) burger.setAttribute('aria-expanded', 'false');
  }
  if (burger) {
    burger.addEventListener('click', function () {
      var open = document.body.classList.toggle('menu-open');
      var nav = document.getElementById('nav');
      if (nav) nav.classList.toggle('menu-open', open);
      burger.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
    document.querySelectorAll('.mobile-menu a').forEach(function (a) {
      a.addEventListener('click', closeMenu);
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') closeMenu();
    });
  }

  /* ---------- появление секций при прокрутке ---------- */
  var revealed = document.querySelectorAll('.wd-rev');
  if (reducedMotion || !('IntersectionObserver' in window)) {
    revealed.forEach(function (el) { el.classList.add('wd-in'); });
  } else {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting) { en.target.classList.add('wd-in'); io.unobserve(en.target); }
      });
    }, { rootMargin: '0px 0px -8% 0px', threshold: 0.05 });
    revealed.forEach(function (el) { io.observe(el); });
  }

  /* ---------- фон hero: статичное звёздное поле на канвасе ---------- */
  (function heroCanvas() {
    var canvas = document.getElementById('cosmic');
    if (!canvas || !canvas.getContext) return;
    function draw() {
      var w = canvas.clientWidth, h = canvas.clientHeight;
      if (!w || !h) return;
      var dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = w * dpr; canvas.height = h * dpr;
      var ctx = canvas.getContext('2d');
      ctx.scale(dpr, dpr);
      ctx.clearRect(0, 0, w, h);
      var seed = 42;
      function rnd() { seed = (seed * 16807) % 2147483647; return seed / 2147483647; }
      for (var i = 0; i < 110; i++) {
        var x = rnd() * w, y = rnd() * h, r = rnd() * 1.4 + 0.3, a = rnd() * 0.5 + 0.12;
        ctx.beginPath();
        ctx.arc(x, y, r, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(255,255,255,' + a.toFixed(2) + ')';
        ctx.fill();
      }
    }
    draw();
    var rt;
    window.addEventListener('resize', function () { clearTimeout(rt); rt = setTimeout(draw, 200); });
  })();

  /* ============================================================
     Универсальные вкладки (B1 и B3): tablist / tab / tabpanel,
     стрелки по фактической ориентации, Home/End.
     ============================================================ */
  function initTabs(list, onSelect) {
    if (!list) return null;
    var tabs = Array.prototype.slice.call(list.querySelectorAll('[role="tab"]'));

    function isHorizontal() {
      return getComputedStyle(list).flexDirection.indexOf('row') === 0;
    }
    function syncOrientation() {
      list.setAttribute('aria-orientation', isHorizontal() ? 'horizontal' : 'vertical');
    }
    syncOrientation();
    var ort;
    window.addEventListener('resize', function () { clearTimeout(ort); ort = setTimeout(syncOrientation, 200); });

    function select(tab, byUser) {
      tabs.forEach(function (t) {
        var on = t === tab;
        t.setAttribute('aria-selected', on ? 'true' : 'false');
        t.tabIndex = on ? 0 : -1;
      });
      onSelect(tab, byUser);
    }
    tabs.forEach(function (t) {
      t.addEventListener('click', function () { select(t, true); });
    });
    list.addEventListener('keydown', function (e) {
      var i = tabs.indexOf(document.activeElement);
      if (i < 0) return;
      var horizontal = isHorizontal(), next = null;
      if ((horizontal && e.key === 'ArrowRight') || (!horizontal && e.key === 'ArrowDown')) next = tabs[(i + 1) % tabs.length];
      else if ((horizontal && e.key === 'ArrowLeft') || (!horizontal && e.key === 'ArrowUp')) next = tabs[(i - 1 + tabs.length) % tabs.length];
      else if (e.key === 'Home') next = tabs[0];
      else if (e.key === 'End') next = tabs[tabs.length - 1];
      if (next) { e.preventDefault(); next.focus(); select(next, true); }
    });
    return { select: select, tabs: tabs };
  }

  /* ---------- B1: переключение примеров ---------- */
  var demoList = document.querySelector('.wd-tabs[role="tablist"]');
  initTabs(demoList, function (tab, byUser) {
    document.querySelectorAll('.wd-demo-stage .wd-panel').forEach(function (p) {
      p.hidden = p.id !== tab.getAttribute('aria-controls');
    });
    if (byUser) track('web_demo_tab_select', { tab: tab.getAttribute('data-wd-tab') });
  });

  /* ---------- B1 · вкладка 01: тестовая заявка ---------- */
  (function demoLead() {
    var btn = document.getElementById('wdDemoSend');
    if (!btn) return;
    var card = document.getElementById('wdCrmCard');
    var empty = document.getElementById('wdCrmEmpty');
    var count = document.getElementById('wdCrmCount');
    var note = document.getElementById('wdD1Note');
    var sent = false, lock = false;
    btn.addEventListener('click', function () {
      if (lock) return;
      lock = true; setTimeout(function () { lock = false; }, 400);
      if (!sent) {
        sent = true;
        card.hidden = false;
        empty.hidden = true;
        count.textContent = '1';
        btn.textContent = 'Готово! Повторить пример ↺';
        note.textContent = 'Тестовая заявка в карточке: контакт, задача и источник. Это локальная демонстрация.';
        track('web_demo_lead_test', { demo: true });
      } else {
        sent = false;
        card.hidden = true;
        empty.hidden = false;
        count.textContent = '0';
        btn.textContent = 'Отправить тестовую заявку';
        note.textContent = 'Попробуйте отправить заявку. Данные никуда не отправляются.';
      }
    });
  })();

  /* ---------- B1 · вкладка 02: редактор и предпросмотр ---------- */
  (function demoEditor() {
    var input = document.getElementById('wdEditInput');
    var title = document.getElementById('wdPvTitle');
    var hint = document.getElementById('wdD2Hint');
    if (!input || !title) return;
    var touched = false;
    input.addEventListener('input', function () {
      var v = input.value;
      title.textContent = v.trim() === '' ? 'Ваш заголовок' : v;
      if (!touched) { touched = true; hint.textContent = 'Предпросмотр обновлён'; }
    });
  })();

  /* ---------- B3: этапы и документ ---------- */
  var WD_STEPS = {
    1: {
      kicker: 'РЕЗУЛЬТАТ ПЕРВОГО ЭТАПА',
      title: 'Паспорт проекта',
      note: 'Общее понимание задачи — до первой строчки кода.',
      rows: [['Задача', 'Что должен решать сайт'], ['Объём', 'Страницы и функции'], ['План', 'Этапы и сроки'], ['Бюджет', 'Согласованная смета']],
      foot: 'У вас — понятный план и стоимость'
    },
    2: {
      kicker: 'РЕЗУЛЬТАТ ВТОРОГО ЭТАПА',
      title: 'Согласованный дизайн',
      note: 'Вы видите будущий сайт и можете пройти путь клиента.',
      rows: [['Структура', 'Логика и навигация'], ['Прототип', 'Сценарии ключевых страниц'], ['Дизайн', 'Макеты и состояния'], ['Адаптив', 'Версия для телефона']],
      foot: 'У вас — макеты и согласованная логика'
    },
    3: {
      kicker: 'РЕЗУЛЬТАТ ТРЕТЬЕГО ЭТАПА',
      title: 'Рабочая версия сайта',
      note: 'Можно открыть, нажать на кнопки и проверить сценарии.',
      rows: [['Страницы', 'Собраны по макетам'], ['Связи', 'Настроены интеграции'], ['Проверка', 'Формы и ключевые сценарии'], ['Устройства', 'Телефоны и компьютеры']],
      foot: 'У вас — сайт для проверки до запуска'
    },
    4: {
      kicker: 'РЕЗУЛЬТАТ ЧЕТВЁРТОГО ЭТАПА',
      title: 'Всё для работы',
      note: 'Сайт запущен. Всё необходимое для управления — у вас.',
      rows: [['Публикация', 'Сайт на вашем домене'], ['Материалы', 'Исходники и макеты'], ['Доступы', 'Хостинг, CMS и сервисы'], ['Инструкция', 'Как управлять сайтом']],
      foot: 'У вас — сайт, доступы и понятные инструкции'
    }
  };
  var stepsList = document.querySelector('.wd-steps[role="tablist"]');
  initTabs(stepsList, function (tab, byUser) {
    var n = tab.getAttribute('data-wd-step');
    var d = WD_STEPS[n];
    if (!d) return;
    document.getElementById('wdDocKicker').textContent = d.kicker;
    document.getElementById('wdDocTitle').textContent = d.title;
    document.getElementById('wdDocNote').textContent = d.note;
    var rows = document.getElementById('wdDocRows');
    rows.textContent = '';
    d.rows.forEach(function (r) {
      var div = document.createElement('div');
      div.className = 'wd-doc-row';
      var dt = document.createElement('dt'); dt.textContent = r[0];
      var dd = document.createElement('dd'); dd.textContent = r[1];
      div.appendChild(dt); div.appendChild(dd);
      rows.appendChild(div);
    });
    document.getElementById('wdDocFoot').textContent = d.foot;
    document.getElementById('wdDoc').setAttribute('aria-labelledby', tab.id);
    if (byUser) track('web_process_select', { step: Number(n) });
  });

  /* ---------- B2: выбор формата из карточек ---------- */
  document.querySelectorAll('[data-wd-format]').forEach(function (a) {
    a.addEventListener('click', function () {
      var v = a.getAttribute('data-wd-format');
      var input = document.querySelector('#wdChips input[value="' + v + '"]');
      if (input) input.checked = true;
      track('web_service_select', { format: v });
    });
  });

  /* ---------- контактные клики ---------- */
  document.querySelectorAll('[data-wd-contact]').forEach(function (a) {
    a.addEventListener('click', function () {
      track('web_contact_click', {
        channel: a.getAttribute('data-wd-contact'),
        source_block: a.closest('.wd-foot') ? 'footer' : (a.closest('.wd-form') ? 'form_error' : 'contact')
      });
    });
  });

  /* ============================================================
     B4 · Реальная отправка формы в /mail.php
     ============================================================ */
  (function leadForm() {
    var form = document.getElementById('wdLeadForm');
    if (!form) return;
    var btn = document.getElementById('wdSubmit');
    var btnTxt = document.getElementById('wdSubmitTxt');
    var note = document.getElementById('wdFormNote');
    var contact = document.getElementById('wdContact');
    var contactGroup = document.getElementById('wdContactGroup');
    var contactErr = document.getElementById('wdContactErr');
    var busy = false;

    function getFormat() {
      var r = form.querySelector('input[name="format"]:checked');
      return r ? r.value : 'Нужен совет';
    }
    function setBusy(on) {
      busy = on;
      btn.disabled = on;
      btn.setAttribute('data-busy', on ? '1' : '0');
      btnTxt.textContent = on ? 'Отправляем…' : 'Написать о проекте ↗';
    }
    function showError(html) {
      note.classList.add('wd-note-err');
      note.innerHTML = html;
    }
    function clearNote() {
      note.classList.remove('wd-note-err');
      note.textContent = '';
    }
    function utmString() {
      try {
        var q = new URLSearchParams(location.search), parts = [];
        q.forEach(function (v, k) { if (/^utm_/i.test(k)) parts.push(k + '=' + v); });
        return parts.join('; ');
      } catch (e) { return ''; }
    }
    function rid() {
      return 'wd-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 10);
    }

    contact.addEventListener('input', function () {
      if (contact.value.trim() !== '') {
        contactGroup.classList.remove('wd-err');
        contactErr.hidden = true;
        contact.removeAttribute('aria-invalid');
      }
    });

    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (busy) return;
      clearNote();

      var contactVal = contact.value.trim();
      if (contactVal === '') {
        contactGroup.classList.add('wd-err');
        contactErr.hidden = false;
        contact.setAttribute('aria-invalid', 'true');
        contact.focus();
        return;
      }

      var name = (document.getElementById('wdName').value || '').trim().slice(0, 80);
      var desc = (document.getElementById('wdDesc').value || '').trim().slice(0, 3000);
      var format = getFormat();
      var page = location.origin + location.pathname;
      var utm = utmString();

      var lines = ['Заявка с сайта NODA · Сайты и приложения'];
      if (name) lines.push('Имя: ' + name);
      lines.push('Контакт: ' + contactVal.slice(0, 120));
      lines.push('Формат: ' + format);
      if (desc) lines.push('Задача: ' + desc);
      lines.push('Форма: noda_web_development');
      lines.push('Страница: ' + page);
      if (utm) lines.push('UTM: ' + utm);

      var payload = {
        form_id: 'noda_web_development',
        name: name,
        contact: contactVal.slice(0, 120),
        format: format,
        description: desc,
        page: page,
        utm: utm,
        website: (document.getElementById('wdWebsite').value || ''),
        _rid: rid(),
        _subject: 'Заявка с сайта NODA · Сайты и приложения',
        message: lines.join('\n')
      };

      setBusy(true);
      var ac = ('AbortController' in window) ? new AbortController() : null;
      var timer = setTimeout(function () { if (ac) ac.abort(); }, 15000);

      fetch('/mail.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
        signal: ac ? ac.signal : undefined
      }).then(function (res) {
        return res.json().catch(function () { return {}; }).then(function (data) {
          return { ok: res.ok, status: res.status, data: data };
        });
      }).then(function (r) {
        clearTimeout(timer);
        setBusy(false);
        if (r.ok && r.data && String(r.data.success) === 'true') {
          form.setAttribute('data-state', 'success');
          track('web_lead_success', { form_id: 'noda_web_development', format: format });
        } else {
          var type = r.status === 429 ? 'ratelimit' : 'server';
          showError('Не удалось отправить заявку. Попробуйте ещё раз или напишите нам в <a href="https://t.me/noda_development" target="_blank" rel="noopener" data-wd-contact="telegram">Telegram</a>.');
          bindErrTg();
          track('web_lead_error', { error_type: type });
        }
      }).catch(function (err) {
        clearTimeout(timer);
        setBusy(false);
        var type = (err && err.name === 'AbortError') ? 'timeout' : 'network';
        showError('Не удалось отправить заявку. Попробуйте ещё раз или напишите нам в <a href="https://t.me/noda_development" target="_blank" rel="noopener" data-wd-contact="telegram">Telegram</a>.');
        bindErrTg();
        track('web_lead_error', { error_type: type });
      });
    });

    function bindErrTg() {
      var a = note.querySelector('[data-wd-contact]');
      if (a) a.addEventListener('click', function () {
        track('web_contact_click', { channel: 'telegram', source_block: 'form_error' });
      });
    }

    var again = document.getElementById('wdAgain');
    if (again) again.addEventListener('click', function () {
      form.removeAttribute('data-state');
      clearNote();
      contact.focus();
    });
  })();

  /* ---------- F1 · футер ---------- */
  var yearEl = document.getElementById('wdYear');
  if (yearEl) yearEl.textContent = String(new Date().getFullYear());
  function toTop(e) {
    if (e) e.preventDefault();
    window.scrollTo({ top: 0, behavior: reducedMotion ? 'auto' : 'smooth' });
  }
  var topBtn = document.getElementById('wdTop');
  if (topBtn) topBtn.addEventListener('click', toTop);
  var brandTop = document.getElementById('wdBrandTop');
  if (brandTop) brandTop.addEventListener('click', toTop);
})();
