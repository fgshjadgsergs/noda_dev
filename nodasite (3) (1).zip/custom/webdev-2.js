/* ============================================================
   NODA · Логика новых блоков страницы «Сайты и приложения»
   (B1 демо, B2 форматы, B3 этапы, B4 форма, F1 футер).
   Подключается только на этой странице; ванильный JS без
   библиотек. Демо-примеры работают локально и никуда не
   отправляют данные; настоящая заявка уходит POST в /mail.php.
   ============================================================ */
(function () {
  'use strict';

  var reducedMotion = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ---------- аналитика: единый адаптер (Яндекс Метрика) ---------- */
  var YM_ID = 110366569;
  function track(name, params) {
    try {
      if (typeof window.ym === 'function') window.ym(YM_ID, 'reachGoal', name, params || {});
    } catch (e) { /* аналитика не должна ломать интерфейс */ }
  }

  /* ---------- плавная прокрутка к якорям ---------- */
  if (!reducedMotion) document.documentElement.style.scrollBehavior = 'smooth';

  /* ---------- фон шапки при прокрутке ---------- */
  var navEl = document.getElementById('nav');
  if (navEl) {
    var onScroll = function () { navEl.classList.toggle('scrolled', window.scrollY > 8); };
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
  }

  /* ---------- мобильное меню (бургер) ---------- */
  var burger = document.querySelector('.nav-burger');
  function closeMenu() {
    document.body.classList.remove('menu-open');
    var nav = document.getElementById('nav');
    if (nav) nav.classList.remove('menu-open');
    if (burger) burger.setAttribute('aria-expanded', 'false');
  }
  if (burger) {
    burger.addEventListener('click', function () {
      var open = document.body.classList.toggle('menu-open');
      var nav = document.getElementById('nav');
      if (nav) nav.classList.toggle('menu-open', open);
      burger.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
    document.querySelectorAll('.mobile-menu a').forEach(function (a) {
      a.addEventListener('click', closeMenu);
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') closeMenu();
    });
  }

  /* ---------- появление секций при прокрутке ---------- */
  var revealed = document.querySelectorAll('.wd-rev');
  if (reducedMotion || !('IntersectionObserver' in window)) {
    revealed.forEach(function (el) { el.classList.add('wd-in'); });
  } else {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting) { en.target.classList.add('wd-in'); io.unobserve(en.target); }
      });
    }, { rootMargin: '0px 0px -8% 0px', threshold: 0.05 });
    revealed.forEach(function (el) { io.observe(el); });
  }

  /* ---------- фон hero: оригинальное «космическое кольцо» (WebGL) ----------
     Точный перенос рендерера из прежней сборки сайта (каркасный тор
     с градиентом, звёздное поле, вращение и параллакс от курсора).
     При prefers-reduced-motion рисуется один статичный кадр. */
  (function heroCosmic() {
    var canvas = document.getElementById('cosmic');
    if (!canvas) return;
    var isMobile = matchMedia('(max-width:900px),(pointer:coarse)').matches;

    /* программные растеризаторы WebGL не тянут — как в оригинале, пропускаем */
    function badWebGL() {
      var bad = false;
      try {
        var g = document.createElement('canvas').getContext('webgl');
        if (g) {
          var ext = g.getExtension('WEBGL_debug_renderer_info');
          var r = ext ? String(g.getParameter(ext.UNMASKED_RENDERER_WEBGL)) : '';
          bad = /swiftshader|llvmpipe|softpipe|software|basic render/i.test(r);
          var lose = g.getExtension('WEBGL_lose_context');
          if (lose) lose.loseContext();
        } else bad = true;
      } catch (e) { }
      if (bad) document.documentElement.classList.add('gl-soft');
      return bad;
    }
    if (badWebGL()) return;

    var gl = canvas.getContext('webgl', { alpha: true, antialias: true, premultipliedAlpha: false });
    if (!gl) return;

    var lineVerts = [], lineCols = [];
    var C1 = [.42, .34, 1], C2 = [.18, .85, .92], C3 = [1, .36, .66];
    function grad(t) {
      var a, b, k;
      if (t < .5) { a = C1; b = C2; k = t / .5; } else { a = C2; b = C3; k = (t - .5) / .5; }
      return [a[0] + (b[0] - a[0]) * k, a[1] + (b[1] - a[1]) * k, a[2] + (b[2] - a[2]) * k];
    }
    function pushLine(p1, p2) {
      lineVerts.push(p1[0], p1[1], p1[2], p2[0], p2[1], p2[2]);
      var c1 = grad(p1[3]), c2 = grad(p2[3]);
      lineCols.push(c1[0], c1[1], c1[2], c2[0], c2[1], c2[2]);
    }
    function ring(R, r, nMaj, nMin) {
      var pts = [];
      for (var i = 0; i < nMaj; i++) {
        var A = i / nMaj * 6.2831;
        for (var j = 0; j < nMin; j++) {
          var B = j / nMin * 6.2831;
          pts.push([(R + r * Math.cos(B)) * Math.cos(A), r * Math.sin(B), (R + r * Math.cos(B)) * Math.sin(A), i / nMaj]);
        }
      }
      var at = function (i, j) { return (i % nMaj) * nMin + (j % nMin); };
      for (var i2 = 0; i2 < nMaj; i2++) for (var j2 = 0; j2 < nMin; j2++) {
        pushLine(pts[at(i2, j2)], pts[at(i2 + 1, j2)]);
        pushLine(pts[at(i2, j2)], pts[at(i2, j2 + 1)]);
      }
    }
    ring(1.35, .34, 92, 14);
    ring(.8, .1, 64, 8);
    for (var s = 0; s < 12; s++) {
      var a12 = s / 12 * 6.2831;
      pushLine([.8 * Math.cos(a12), 0, .8 * Math.sin(a12), s / 12], [1.35 * Math.cos(a12), 0, 1.35 * Math.sin(a12), s / 12]);
    }
    for (var s6 = 0; s6 < 6; s6++) {
      var a6 = s6 / 6 * 6.2831;
      pushLine([0, 0, 0, .5], [.8 * Math.cos(a6), 0, .8 * Math.sin(a6), .5]);
    }

    var starVerts = [], starCols = [];
    var starCount = isMobile ? 260 : 440, seed = 987654;
    function rnd() { seed = 16807 * seed % 2147483647; return seed / 2147483647; }
    for (var st = 0; st < starCount; st++) {
      var th = 6.2831 * rnd(), ph = Math.acos(2 * rnd() - 1), R3 = 3 + 6 * rnd();
      starVerts.push(R3 * Math.sin(ph) * Math.cos(th), R3 * Math.cos(ph), R3 * Math.sin(ph) * Math.sin(th));
      var br = .35 + .6 * rnd();
      starCols.push(br, br, 1.15 * br);
    }

    function shader(type, srcText) {
      var sh = gl.createShader(type);
      gl.shaderSource(sh, srcText);
      gl.compileShader(sh);
      return sh;
    }
    /* Отличие от прежней сборки: у линий модели проекция без перспективного
       масштаба (uSize — размер в пикселях на мировую единицу), поэтому кольцо
       вращается строго вокруг закреплённого центра, не «разрастаясь» и не
       уезжая к краям при поворотах и изменении высоты канваса. Глубина
       остаётся в яркости линий (vd) и в перспективе звёздного поля. */
    var prog = gl.createProgram();
    gl.attachShader(prog, shader(gl.VERTEX_SHADER,
      'attribute vec3 pos;attribute vec3 col;varying vec3 vc;varying float vd;uniform mat3 uR;uniform vec2 uRes;uniform float uStar;uniform float uOffX;uniform float uSize;\n' +
      'void main(){vec3 q=uR*pos;q.z+=4.4;float pe=2.8/q.z;vec2 p;\n' +
      'if(uStar>.5){p=q.xy*pe;p.x*=uRes.y/uRes.x;}else{p=q.xy*(uSize*2.0/uRes);}\n' +
      'p.x+=uOffX;\n' +
      'gl_Position=vec4(p,0.0,1.0);gl_PointSize=uStar>.5?max(1.0,pe*1.7):1.0;vc=col;vd=pe;}'));
    gl.attachShader(prog, shader(gl.FRAGMENT_SHADER,
      'precision highp float;varying vec3 vc;varying float vd;uniform float uStar;\n' +
      'void main(){if(uStar>.5){vec2 d=gl_PointCoord-.5;float a=smoothstep(.5,0.,length(d));gl_FragColor=vec4(vc,a*.7);}\n' +
      'else{gl_FragColor=vec4(vc*(.6+vd*1.35),1.0);}}'));
    gl.linkProgram(prog);
    if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) return;

    function buf(arr) {
      var b = gl.createBuffer();
      gl.bindBuffer(gl.ARRAY_BUFFER, b);
      gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(arr), gl.STATIC_DRAW);
      return b;
    }
    gl.useProgram(prog);
    var bLineV = buf(lineVerts), bLineC = buf(lineCols), bStarV = buf(starVerts), bStarC = buf(starCols);
    var aPos = gl.getAttribLocation(prog, 'pos'), aCol = gl.getAttribLocation(prog, 'col');
    var uR = gl.getUniformLocation(prog, 'uR'), uRes = gl.getUniformLocation(prog, 'uRes');
    var uStar = gl.getUniformLocation(prog, 'uStar'), uOffX = gl.getUniformLocation(prog, 'uOffX');
    var uSize = gl.getUniformLocation(prog, 'uSize');
    function bindPair(v, c) {
      gl.bindBuffer(gl.ARRAY_BUFFER, v);
      gl.enableVertexAttribArray(aPos);
      gl.vertexAttribPointer(aPos, 3, gl.FLOAT, false, 0, 0);
      gl.bindBuffer(gl.ARRAY_BUFFER, c);
      gl.enableVertexAttribArray(aCol);
      gl.vertexAttribPointer(aCol, 3, gl.FLOAT, false, 0, 0);
    }
    var sizePx = 0; /* px на мировую единицу — фиксирует размер модели */
    function resize() {
      var dpr = Math.min(devicePixelRatio || 1, isMobile ? .95 : 1.4);
      canvas.width = canvas.clientWidth * dpr;
      canvas.height = canvas.clientHeight * dpr;
      gl.viewport(0, 0, canvas.width, canvas.height);
      sizePx = (isMobile ? 190 : 290) * dpr;
    }
    gl.enable(gl.BLEND);
    gl.blendFunc(gl.SRC_ALPHA, gl.ONE);
    gl.disable(gl.DEPTH_TEST);
    addEventListener('resize', resize);
    resize();

    var mx = .5, my = .5, tx = .5, ty = .5;
    var nLines = lineVerts.length / 3, nStars = starVerts.length / 3;
    function rot(x, y) {
      var cx = Math.cos(x), sx = Math.sin(x), cy = Math.cos(y), sy = Math.sin(y);
      return [cy, 0, sy, sx * sy, cx, -sx * cy, -cx * sy, sx, cx * cy];
    }
    function frame(t) {
      mx += (tx - mx) * .03;
      my += (ty - my) * .03;
      var m = rot(.6 + (my - .5) * .45, .12 * t + (mx - .5) * .7);
      gl.useProgram(prog);
      gl.uniformMatrix3fv(uR, false, new Float32Array(m));
      gl.uniform2f(uRes, canvas.width, canvas.height);
      gl.uniform1f(uOffX, canvas.width > canvas.height ? .42 : 0);
      gl.uniform1f(uSize, sizePx);
      gl.clearColor(0, 0, 0, 0);
      gl.clear(gl.COLOR_BUFFER_BIT);
      gl.uniform1f(uStar, 1);
      bindPair(bStarV, bStarC);
      gl.drawArrays(gl.POINTS, 0, nStars);
      gl.uniform1f(uStar, 0);
      bindPair(bLineV, bLineC);
      gl.drawArrays(gl.LINES, 0, nLines);
    }

    if (reducedMotion) { frame(0); return; }

    addEventListener('mousemove', function (e) {
      tx = e.clientX / innerWidth;
      ty = e.clientY / innerHeight;
    });
    var inView = true;
    if ('IntersectionObserver' in window) {
      try {
        new IntersectionObserver(function (en) { inView = en[en.length - 1].isIntersecting; }, { rootMargin: '220px' }).observe(canvas);
      } catch (e) { }
    }
    var t0 = null;
    function loop(now) {
      requestAnimationFrame(loop);
      if (!inView || document.hidden) return;
      if (t0 === null) t0 = now;
      frame((now - t0) / 1000);
    }
    requestAnimationFrame(loop);
  })();

  /* ============================================================
     Универсальные вкладки (B1 и B3): tablist / tab / tabpanel,
     стрелки по фактической ориентации, Home/End.
     ============================================================ */
  function initTabs(list, onSelect) {
    if (!list) return null;
    var tabs = Array.prototype.slice.call(list.querySelectorAll('[role="tab"]'));

    function isHorizontal() {
      return getComputedStyle(list).flexDirection.indexOf('row') === 0;
    }
    function syncOrientation() {
      list.setAttribute('aria-orientation', isHorizontal() ? 'horizontal' : 'vertical');
    }
    syncOrientation();
    var ort;
    window.addEventListener('resize', function () { clearTimeout(ort); ort = setTimeout(syncOrientation, 200); });

    function select(tab, byUser) {
      tabs.forEach(function (t) {
        var on = t === tab;
        t.setAttribute('aria-selected', on ? 'true' : 'false');
        t.tabIndex = on ? 0 : -1;
      });
      onSelect(tab, byUser);
    }
    tabs.forEach(function (t) {
      t.addEventListener('click', function () { select(t, true); });
    });
    list.addEventListener('keydown', function (e) {
      var i = tabs.indexOf(document.activeElement);
      if (i < 0) return;
      var horizontal = isHorizontal(), next = null;
      if ((horizontal && e.key === 'ArrowRight') || (!horizontal && e.key === 'ArrowDown')) next = tabs[(i + 1) % tabs.length];
      else if ((horizontal && e.key === 'ArrowLeft') || (!horizontal && e.key === 'ArrowUp')) next = tabs[(i - 1 + tabs.length) % tabs.length];
      else if (e.key === 'Home') next = tabs[0];
      else if (e.key === 'End') next = tabs[tabs.length - 1];
      if (next) { e.preventDefault(); next.focus(); select(next, true); }
    });
    return { select: select, tabs: tabs };
  }

  /* ---------- B1: переключение примеров ---------- */
  var demoList = document.querySelector('.wd-tabs[role="tablist"]');
  initTabs(demoList, function (tab, byUser) {
    document.querySelectorAll('.wd-demo-stage .wd-panel').forEach(function (p) {
      p.hidden = p.id !== tab.getAttribute('aria-controls');
    });
    if (byUser) track('web_demo_tab_select', { tab: tab.getAttribute('data-wd-tab') });
  });

  /* ---------- B1 · вкладка 01: тестовая заявка ---------- */
  (function demoLead() {
    var btn = document.getElementById('wdDemoSend');
    if (!btn) return;
    var card = document.getElementById('wdCrmCard');
    var empty = document.getElementById('wdCrmEmpty');
    var count = document.getElementById('wdCrmCount');
    var note = document.getElementById('wdD1Note');
    var sent = false, lock = false;
    btn.addEventListener('click', function () {
      if (lock) return;
      lock = true; setTimeout(function () { lock = false; }, 400);
      if (!sent) {
        sent = true;
        card.hidden = false;
        empty.hidden = true;
        count.textContent = '1';
        btn.textContent = 'Готово! Повторить пример ↺';
        note.textContent = 'Тестовая заявка в карточке: контакт, задача и источник. Это локальная демонстрация.';
        track('web_demo_lead_test', { demo: true });
      } else {
        sent = false;
        card.hidden = true;
        empty.hidden = false;
        count.textContent = '0';
        btn.textContent = 'Отправить тестовую заявку';
        note.textContent = 'Попробуйте отправить заявку. Данные никуда не отправляются.';
      }
    });
  })();

  /* ---------- B1 · вкладка 02: редактор и предпросмотр ---------- */
  (function demoEditor() {
    var input = document.getElementById('wdEditInput');
    var title = document.getElementById('wdPvTitle');
    var hint = document.getElementById('wdD2Hint');
    if (!input || !title) return;
    var touched = false;
    input.addEventListener('input', function () {
      var v = input.value;
      title.textContent = v.trim() === '' ? 'Ваш заголовок' : v;
      if (!touched) { touched = true; hint.textContent = 'Предпросмотр обновлён'; }
    });
  })();

  /* ---------- B3: этапы и документ ---------- */
  var WD_STEPS = {
    1: {
      kicker: 'РЕЗУЛЬТАТ ПЕРВОГО ЭТАПА',
      title: 'Паспорт проекта',
      note: 'Общее понимание задачи — до первой строчки кода.',
      rows: [['Задача', 'Что должен решать сайт'], ['Объём', 'Страницы и функции'], ['План', 'Этапы и сроки'], ['Бюджет', 'Согласованная смета']],
      foot: 'У вас — понятный план и стоимость'
    },
    2: {
      kicker: 'РЕЗУЛЬТАТ ВТОРОГО ЭТАПА',
      title: 'Согласованный дизайн',
      note: 'Вы видите будущий сайт и можете пройти путь клиента.',
      rows: [['Структура', 'Логика и навигация'], ['Прототип', 'Сценарии ключевых страниц'], ['Дизайн', 'Макеты и состояния'], ['Адаптив', 'Версия для телефона']],
      foot: 'У вас — макеты и согласованная логика'
    },
    3: {
      kicker: 'РЕЗУЛЬТАТ ТРЕТЬЕГО ЭТАПА',
      title: 'Рабочая версия сайта',
      note: 'Можно открыть, нажать на кнопки и проверить сценарии.',
      rows: [['Страницы', 'Собраны по макетам'], ['Связи', 'Настроены интеграции'], ['Проверка', 'Формы и ключевые сценарии'], ['Устройства', 'Телефоны и компьютеры']],
      foot: 'У вас — сайт для проверки до запуска'
    },
    4: {
      kicker: 'РЕЗУЛЬТАТ ЧЕТВЁРТОГО ЭТАПА',
      title: 'Всё для работы',
      note: 'Сайт запущен. Всё необходимое для управления — у вас.',
      rows: [['Публикация', 'Сайт на вашем домене'], ['Материалы', 'Исходники и макеты'], ['Доступы', 'Хостинг, CMS и сервисы'], ['Инструкция', 'Как управлять сайтом']],
      foot: 'У вас — сайт, доступы и понятные инструкции'
    }
  };
  var stepsList = document.querySelector('.wd-steps[role="tablist"]');
  initTabs(stepsList, function (tab, byUser) {
    var n = tab.getAttribute('data-wd-step');
    var d = WD_STEPS[n];
    if (!d) return;
    document.getElementById('wdDocKicker').textContent = d.kicker;
    document.getElementById('wdDocTitle').textContent = d.title;
    document.getElementById('wdDocNote').textContent = d.note;
    var rows = document.getElementById('wdDocRows');
    rows.textContent = '';
    d.rows.forEach(function (r) {
      var div = document.createElement('div');
      div.className = 'wd-doc-row';
      var dt = document.createElement('dt'); dt.textContent = r[0];
      var dd = document.createElement('dd'); dd.textContent = r[1];
      div.appendChild(dt); div.appendChild(dd);
      rows.appendChild(div);
    });
    document.getElementById('wdDocFoot').textContent = d.foot;
    document.getElementById('wdDoc').setAttribute('aria-labelledby', tab.id);
    if (byUser) track('web_process_select', { step: Number(n) });
  });

  /* ---------- B2: выбор формата из карточек ---------- */
  document.querySelectorAll('[data-wd-format]').forEach(function (a) {
    a.addEventListener('click', function () {
      var v = a.getAttribute('data-wd-format');
      var input = document.querySelector('#wdChips input[value="' + v + '"]');
      if (input) input.checked = true;
      track('web_service_select', { format: v });
    });
  });

  /* ---------- контактные клики ---------- */
  document.querySelectorAll('[data-wd-contact]').forEach(function (a) {
    a.addEventListener('click', function () {
      track('web_contact_click', {
        channel: a.getAttribute('data-wd-contact'),
        source_block: a.closest('.wd-foot') ? 'footer' : (a.closest('.wd-form') ? 'form_error' : 'contact')
      });
    });
  });

  /* ============================================================
     B4 · Реальная отправка формы в /mail.php
     ============================================================ */
  (function leadForm() {
    var form = document.getElementById('wdLeadForm');
    if (!form) return;
    var btn = document.getElementById('wdSubmit');
    var btnTxt = document.getElementById('wdSubmitTxt');
    var note = document.getElementById('wdFormNote');
    var contact = document.getElementById('wdContact');
    var contactGroup = document.getElementById('wdContactGroup');
    var contactErr = document.getElementById('wdContactErr');
    var busy = false;

    function getFormat() {
      var r = form.querySelector('input[name="format"]:checked');
      return r ? r.value : 'Нужен совет';
    }
    function setBusy(on) {
      busy = on;
      btn.disabled = on;
      btn.setAttribute('data-busy', on ? '1' : '0');
      btnTxt.textContent = on ? 'Отправляем…' : 'Написать о проекте ↗';
    }
    function showError(html) {
      note.classList.add('wd-note-err');
      note.innerHTML = html;
    }
    function clearNote() {
      note.classList.remove('wd-note-err');
      note.textContent = '';
    }
    function utmString() {
      try {
        var q = new URLSearchParams(location.search), parts = [];
        q.forEach(function (v, k) { if (/^utm_/i.test(k)) parts.push(k + '=' + v); });
        return parts.join('; ');
      } catch (e) { return ''; }
    }
    function rid() {
      return 'wd-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 10);
    }

    contact.addEventListener('input', function () {
      if (contact.value.trim() !== '') {
        contactGroup.classList.remove('wd-err');
        contactErr.hidden = true;
        contact.removeAttribute('aria-invalid');
      }
    });

    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (busy) return;
      clearNote();

      var contactVal = contact.value.trim();
      if (contactVal === '') {
        contactGroup.classList.add('wd-err');
        contactErr.hidden = false;
        contact.setAttribute('aria-invalid', 'true');
        contact.focus();
        return;
      }

      var name = (document.getElementById('wdName').value || '').trim().slice(0, 80);
      var desc = (document.getElementById('wdDesc').value || '').trim().slice(0, 3000);
      var format = getFormat();
      var page = location.origin + location.pathname;
      var utm = utmString();

      var lines = ['Заявка с сайта NODA · Сайты и приложения'];
      if (name) lines.push('Имя: ' + name);
      lines.push('Контакт: ' + contactVal.slice(0, 120));
      lines.push('Формат: ' + format);
      if (desc) lines.push('Задача: ' + desc);
      lines.push('Форма: noda_web_development');
      lines.push('Страница: ' + page);
      if (utm) lines.push('UTM: ' + utm);

      var payload = {
        form_id: 'noda_web_development',
        name: name,
        contact: contactVal.slice(0, 120),
        format: format,
        description: desc,
        page: page,
        utm: utm,
        website: (document.getElementById('wdWebsite').value || ''),
        _rid: rid(),
        _subject: 'Заявка с сайта NODA · Сайты и приложения',
        message: lines.join('\n')
      };

      setBusy(true);
      var ac = ('AbortController' in window) ? new AbortController() : null;
      var timer = setTimeout(function () { if (ac) ac.abort(); }, 15000);

      fetch('/mail.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
        signal: ac ? ac.signal : undefined
      }).then(function (res) {
        return res.json().catch(function () { return {}; }).then(function (data) {
          return { ok: res.ok, status: res.status, data: data };
        });
      }).then(function (r) {
        clearTimeout(timer);
        setBusy(false);
        if (r.ok && r.data && String(r.data.success) === 'true') {
          form.setAttribute('data-state', 'success');
          track('web_lead_success', { form_id: 'noda_web_development', format: format });
        } else {
          var type = r.status === 429 ? 'ratelimit' : 'server';
          showError('Не удалось отправить заявку. Попробуйте ещё раз или напишите нам в <a href="https://t.me/noda_development" target="_blank" rel="noopener" data-wd-contact="telegram">Telegram</a>.');
          bindErrTg();
          track('web_lead_error', { error_type: type });
        }
      }).catch(function (err) {
        clearTimeout(timer);
        setBusy(false);
        var type = (err && err.name === 'AbortError') ? 'timeout' : 'network';
        showError('Не удалось отправить заявку. Попробуйте ещё раз или напишите нам в <a href="https://t.me/noda_development" target="_blank" rel="noopener" data-wd-contact="telegram">Telegram</a>.');
        bindErrTg();
        track('web_lead_error', { error_type: type });
      });
    });

    function bindErrTg() {
      var a = note.querySelector('[data-wd-contact]');
      if (a) a.addEventListener('click', function () {
        track('web_contact_click', { channel: 'telegram', source_block: 'form_error' });
      });
    }

    var again = document.getElementById('wdAgain');
    if (again) again.addEventListener('click', function () {
      form.removeAttribute('data-state');
      clearNote();
      contact.focus();
    });
  })();

  /* ---------- F1 · футер ---------- */
  var yearEl = document.getElementById('wdYear');
  if (yearEl) yearEl.textContent = String(new Date().getFullYear());
  function toTop(e) {
    if (e) e.preventDefault();
    window.scrollTo({ top: 0, behavior: reducedMotion ? 'auto' : 'smooth' });
  }
  var topBtn = document.getElementById('wdTop');
  if (topBtn) topBtn.addEventListener('click', toTop);
  var brandTop = document.getElementById('wdBrandTop');
  if (brandTop) brandTop.addEventListener('click', toTop);
})();
