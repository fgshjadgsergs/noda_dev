/* Keep in-page anchors clear of the actual fixed header, including its
   desktop service menu and responsive font/layout changes. */
(function () {
  'use strict';
  var page = document.body;
  var header = document.getElementById('nav');
  if (!page.classList.contains('noda-service-page') || !header) return;

  var previousHeight = 0;
  function syncHeaderHeight() {
    var height = Math.ceil(header.getBoundingClientRect().height);
    if (height > 0 && height !== previousHeight) {
      previousHeight = height;
      page.style.setProperty('--service-header-height', height + 'px');
    }
  }

  syncHeaderHeight();
  if ('ResizeObserver' in window) {
    new ResizeObserver(syncHeaderHeight).observe(header);
  } else {
    window.addEventListener('resize', syncHeaderHeight, { passive: true });
  }
})();
