/* ============================================================
   NODA · Демонстрационная панель «Управление сайтом».
   Учебный интерфейс: все данные локальные, сетевых отправок нет.
   Обработчики отделены от настоящей формы обращения (mail.php).
   Состояние живёт внутри компонента и сбрасывается перезагрузкой.
   ============================================================ */
(function () {
  'use strict';

  var root = document.getElementById('wdDemoPanel');
  if (!root) return;

  var reduced = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var EN = document.documentElement.lang === 'en';

  var YM_ID = 110366569;
  function track(name, params) {
    try {
      if (typeof window.ym === 'function') window.ym(YM_ID, 'reachGoal', name, params || {});
    } catch (e) { /* аналитика не должна ломать интерфейс */ }
  }

  var msgEl = root.querySelector('#ndpMsg');
  function say(text) { if (msgEl) msgEl.textContent = text; }

  /* ============ вкладки панели ============ */
  var nav = root.querySelector('.ndp-nav');
  var tabs = Array.prototype.slice.call(nav.querySelectorAll('[role="tab"]'));
  var panes = Array.prototype.slice.call(root.querySelectorAll('.ndp-pane'));

  function navHorizontal() {
    return getComputedStyle(nav).flexDirection.indexOf('row') === 0;
  }
  function selectTab(tab, byUser) {
    tabs.forEach(function (t) {
      var on = t === tab;
      t.setAttribute('aria-selected', on ? 'true' : 'false');
      t.tabIndex = on ? 0 : -1;
    });
    panes.forEach(function (p) {
      p.hidden = p.id !== tab.getAttribute('aria-controls');
    });
    if (byUser) track('web_demo_tab_select', { tab: tab.getAttribute('data-ndp-tab') });
  }
  tabs.forEach(function (t) {
    t.addEventListener('click', function () { selectTab(t, true); });
  });
  nav.addEventListener('keydown', function (e) {
    var i = tabs.indexOf(document.activeElement);
    if (i < 0) return;
    var h = navHorizontal(), next = null;
    if ((h && e.key === 'ArrowRight') || (!h && e.key === 'ArrowDown')) next = tabs[(i + 1) % tabs.length];
    else if ((h && e.key === 'ArrowLeft') || (!h && e.key === 'ArrowUp')) next = tabs[(i - 1 + tabs.length) % tabs.length];
    else if (e.key === 'Home') next = tabs[0];
    else if (e.key === 'End') next = tabs[tabs.length - 1];
    if (next) { e.preventDefault(); next.focus(); selectTab(next, true); }
  });

  /* ============ вкладка «Заявки»: раскрытие карточек ============ */
  var list = root.querySelector('#ndpList');
  var countEl = root.querySelector('#ndpCount');
  var openId = null;
  var timers = {};

  function clearTimer(id) {
    if (timers[id]) { clearTimeout(timers[id]); delete timers[id]; }
  }
  function later(id, fn, ms) {
    clearTimer(id);
    timers[id] = setTimeout(function () { delete timers[id]; fn(); }, ms);
  }
  function rowOf(id) { return list.querySelector('.ndp-row[data-id="' + id + '"]'); }
  function wrapOf(id) { return root.querySelector('#ndpCard-' + id); }
  function btnOf(id) { var r = rowOf(id); return r && r.querySelector('.ndp-open'); }

  function setOpenUi(id, on) {
    var row = rowOf(id), btn = btnOf(id);
    if (row) row.classList.toggle('ndp-row-open', on);
    if (btn) {
      btn.setAttribute('aria-expanded', on ? 'true' : 'false');
      btn.querySelector('.ndp-open-txt').textContent = on ? (EN ? 'Collapse' : 'Свернуть') : (EN ? 'Open' : 'Открыть');
      btn.querySelector('.ndp-arr').textContent = on ? '↑' : '→';
    }
  }
  function expand(id) {
    var w = wrapOf(id);
    if (!w) return;
    clearTimer(id);
    w.hidden = false;
    w.classList.remove('ndp-closing');
    if (reduced) {
      w.style.height = 'auto';
    } else {
      var target = w.scrollHeight;
      w.style.height = w.offsetHeight + 'px';
      requestAnimationFrame(function () { w.style.height = target + 'px'; });
      later(id, function () { w.style.height = 'auto'; }, 300);
    }
    setOpenUi(id, true);
  }
  function collapse(id, focusBack) {
    var w = wrapOf(id);
    if (!w) return;
    clearTimer(id);
    if (reduced) {
      w.style.height = '0px';
      w.hidden = true;
    } else {
      w.classList.add('ndp-closing');
      w.style.height = w.offsetHeight + 'px';
      void w.offsetHeight;
      w.style.height = '0px';
      later(id, function () { w.hidden = true; w.classList.remove('ndp-closing'); }, 220);
    }
    setOpenUi(id, false);
    if (focusBack) {
      var b = btnOf(id);
      if (b) b.focus();
    }
  }
  function toggleCard(id) {
    if (openId === id) {
      openId = null;
      collapse(id, false);
      return;
    }
    if (openId != null) collapse(openId, false);
    openId = id;
    expand(id);
    track('web_demo_card_open', { tab: 'leads' });
  }

  list.addEventListener('click', function (e) {
    var x = e.target.closest && e.target.closest('.ndp-card-x');
    if (x) {
      var cid = x.getAttribute('data-for');
      if (openId === cid) openId = null;
      collapse(cid, true);
      return;
    }
    var act = e.target.closest && e.target.closest('.ndp-act');
    if (act) { advanceStatus(act.getAttribute('data-for')); return; }
    if (e.target.closest && e.target.closest('.ndp-card')) return;
    var line = e.target.closest && e.target.closest('.ndp-row-line');
    if (!line) return;
    toggleCard(line.parentNode.getAttribute('data-id'));
  });

  /* ---------- статусная цепочка ---------- */
  var ST = EN ? {
    new: { cls: 'ndp-st-new', txt: 'New', btn: 'Take to work' },
    work: { cls: 'ndp-st-work', txt: 'In progress', btn: 'Approve' },
    done: { cls: 'ndp-st-done', txt: 'Approved', btn: '' }
  } : {
    new: { cls: 'ndp-st-new', txt: 'Новая', btn: 'Взять в работу' },
    work: { cls: 'ndp-st-work', txt: 'В работе', btn: 'Согласовать' },
    done: { cls: 'ndp-st-done', txt: 'Согласовано', btn: '' }
  };
  function paintStatus(el, key) {
    el.className = 'ndp-st ' + ST[key].cls;
    el.textContent = ST[key].txt;
  }
  function advanceStatus(id) {
    var row = rowOf(id), w = wrapOf(id);
    if (!row || !w) return;
    var cur = row.getAttribute('data-status');
    var next = cur === 'new' ? 'work' : cur === 'work' ? 'done' : null;
    if (!next) return;
    row.setAttribute('data-status', next);
    paintStatus(row.querySelector('.ndp-c-status .ndp-st'), next);
    paintStatus(w.querySelector('.ndp-card-foot .ndp-st'), next);
    var resp = w.querySelector('.ndp-resp');
    if (next === 'work' && resp) resp.textContent = EN ? 'You' : 'Вы';
    var act = w.querySelector('.ndp-act');
    if (act) {
      if (next === 'done') {
        var note = document.createElement('span');
        note.className = 'ndp-done-note';
        note.textContent = EN ? 'Approval chain finished' : 'Цепочка согласования завершена';
        act.parentNode.replaceChild(note, act);
      } else {
        act.textContent = ST[next].btn;
      }
    }
    var num = row.getAttribute('data-num');
    say(EN ? ('Lead #' + num + ' — status “' + ST[next].txt + '”') : ('Заявка №' + num + ' — статус «' + ST[next].txt + '»'));
    track('web_demo_status_change', { tab: 'leads', to: next });
    if (openId === id && !reduced) {
      /* высота карточки могла измениться — обновить без анимации */
      w.style.height = 'auto';
    }
  }

  /* ---------- учебная форма добавления ---------- */
  var addBtn = root.querySelector('#ndpAddBtn');
  var addForm = root.querySelector('#ndpAddForm');
  var fName = root.querySelector('#ndpAddName');
  var fTask = root.querySelector('#ndpAddTask');
  var nextNum = 1042;
  var newSeq = 0;

  function setAddOpen(on) {
    addForm.hidden = !on;
    addBtn.setAttribute('aria-expanded', on ? 'true' : 'false');
    if (on) fName.focus();
  }
  addBtn.addEventListener('click', function () {
    setAddOpen(addForm.hidden);
    if (!addForm.hidden) track('web_demo_add_open', { tab: 'leads' });
  });
  root.querySelector('#ndpAddClose').addEventListener('click', function () {
    setAddOpen(false);
    addBtn.focus();
  });

  function fieldError(input, on, text) {
    var fg = input.closest('.ndp-fg');
    fg.classList.toggle('ndp-fg-err', on);
    fg.querySelector('.ndp-err').textContent = on ? text : '';
    if (on) input.setAttribute('aria-invalid', 'true');
    else input.removeAttribute('aria-invalid');
  }
  fName.addEventListener('input', function () { fieldError(fName, false, ''); });
  fTask.addEventListener('input', function () { fieldError(fTask, false, ''); });

  function el(tag, cls, text) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text != null) n.textContent = text;
    return n;
  }
  function prop(label, value, cls) {
    var p = el('div', 'ndp-prop');
    p.appendChild(el('span', null, label));
    p.appendChild(el('b', cls || null, value));
    return p;
  }
  function buildRow(d) {
    var li = el('li', 'ndp-row');
    li.setAttribute('data-id', d.id);
    li.setAttribute('data-num', d.num);
    li.setAttribute('data-status', d.status);

    var line = el('div', 'ndp-row-line');
    var c1 = el('span', 'ndp-c-contact');
    c1.appendChild(el('b', null, d.name));
    c1.appendChild(el('small', null, (EN ? 'Site · #' : 'Сайт · №') + d.num + ' · ' + d.time));
    var c2 = el('span', 'ndp-c-task', d.task);
    var c3 = el('span', 'ndp-c-status');
    var pill = el('i', 'ndp-st ' + ST[d.status].cls, ST[d.status].txt);
    c3.appendChild(pill);
    var c4 = el('span', 'ndp-c-open');
    var btn = el('button', 'ndp-open');
    btn.type = 'button';
    btn.setAttribute('aria-expanded', 'false');
    btn.setAttribute('aria-controls', 'ndpCard-' + d.id);
    btn.appendChild(el('span', 'ndp-open-txt', EN ? 'Open' : 'Открыть'));
    btn.appendChild(el('span', 'ndp-arr', '→'));
    btn.querySelector('.ndp-arr').setAttribute('aria-hidden', 'true');
    c4.appendChild(btn);
    line.appendChild(c1); line.appendChild(c2); line.appendChild(c3); line.appendChild(c4);

    var wr = el('div', 'ndp-cardwr');
    wr.id = 'ndpCard-' + d.id;
    wr.hidden = true;
    var card = el('div', 'ndp-card');
    var head = el('div', 'ndp-card-head');
    var ht = el('div');
    ht.appendChild(el('small', null, (EN ? 'Lead #' : 'Заявка №') + d.num));
    ht.appendChild(el('b', null, d.task));
    var xb = el('button', 'ndp-x ndp-card-x');
    xb.type = 'button';
    xb.setAttribute('data-for', d.id);
    xb.setAttribute('aria-label', (EN ? 'Collapse lead card #' : 'Свернуть карточку заявки №') + d.num);
    xb.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg>';
    head.appendChild(ht); head.appendChild(xb);
    card.appendChild(head);
    card.appendChild(el('p', 'ndp-card-desc', d.desc));
    var props = el('div', 'ndp-props');
    props.appendChild(prop(EN ? 'Name' : 'Имя', d.name));
    props.appendChild(prop(EN ? 'Source' : 'Источник', EN ? 'Website form' : 'Форма на сайте'));
    props.appendChild(prop(EN ? 'Format' : 'Формат', d.format));
    props.appendChild(prop(EN ? 'Contact' : 'Контакт', EN ? '@example · demo' : '@example · демо'));
    props.appendChild(prop(EN ? 'Assignee' : 'Ответственный', d.resp, 'ndp-resp'));
    card.appendChild(props);
    var foot = el('div', 'ndp-card-foot');
    foot.appendChild(el('i', 'ndp-st ' + ST[d.status].cls, ST[d.status].txt));
    if (ST[d.status].btn) {
      var act = el('button', 'ndp-btn-ghost ndp-act', ST[d.status].btn);
      act.type = 'button';
      act.setAttribute('data-for', d.id);
      foot.appendChild(act);
    } else {
      foot.appendChild(el('span', 'ndp-done-note', EN ? 'Approval chain finished' : 'Цепочка согласования завершена'));
    }
    card.appendChild(foot);
    wr.appendChild(card);

    li.appendChild(line);
    li.appendChild(wr);
    return li;
  }

  addForm.addEventListener('submit', function (e) {
    e.preventDefault();
    var name = fName.value.replace(/\s+/g, ' ').trim().slice(0, 35);
    var task = fTask.value.replace(/\s+/g, ' ').trim().slice(0, 55);
    var bad = false;
    if (name === '') { fieldError(fName, true, EN ? 'Enter a name' : 'Укажите имя'); bad = true; }
    if (task === '') { fieldError(fTask, true, EN ? 'Describe the task' : 'Опишите задачу'); bad = true; }
    if (bad) {
      (name === '' ? fName : fTask).focus();
      return;
    }
    var d = {
      id: 'n' + (++newSeq),
      num: nextNum++,
      name: name,
      task: task,
      time: EN ? 'Now' : 'Сейчас',
      status: 'new',
      resp: EN ? 'Unassigned' : 'Не назначен',
      format: EN ? 'To be discussed' : 'Обсуждается',
      desc: (EN ? 'Training record from the demo form. Task: ' : 'Учебная запись из демонстрационной формы. Задача: ') + task + '.'
    };
    list.insertBefore(buildRow(d), list.firstChild);
    countEl.textContent = String(list.querySelectorAll('.ndp-row').length);
    setAddOpen(false);
    fName.value = EN ? 'Alex' : 'Алексей';
    fTask.value = EN ? 'Website for a studio' : 'Сайт для студии';
    addBtn.focus();
    say(EN ? ('Training lead from ' + name + ' appeared in the panel') : ('Учебная заявка от ' + name + ' появилась в панели'));
    track('web_demo_lead_add', { tab: 'leads' });
  });

  /* ---------- мягкая подсказка у первой кнопки ---------- */
  if (!reduced && 'IntersectionObserver' in window) {
    try {
      var nudged = false;
      var nio = new IntersectionObserver(function (en) {
        if (nudged || !en.some(function (x) { return x.isIntersecting; })) return;
        nudged = true;
        nio.disconnect();
        var first = list.querySelector('.ndp-row');
        if (first) {
          first.classList.add('ndp-nudge');
          setTimeout(function () { first.classList.remove('ndp-nudge'); }, 1600);
        }
      }, { threshold: 0.35 });
      nio.observe(list);
    } catch (e) { }
  }

  /* ============ вкладка «Контент»: живой предпросмотр ============ */
  var fTitle = root.querySelector('#ndpFTitle');
  var fDesc = root.querySelector('#ndpFDesc');
  var fBtn = root.querySelector('#ndpFBtn');
  var pvTitles = root.querySelectorAll('.ndp-site-ttl');
  var pvDescs = root.querySelectorAll('.ndp-site-desc');
  var pvBtns = root.querySelectorAll('.ndp-site-btn');
  var sayT = null;

  function renderSite() {
    var t = fTitle.value.trim() === '' ? ' ' : fTitle.value;
    var ds = fDesc.value.trim() === '' ? ' ' : fDesc.value;
    var b = fBtn.value.trim() === '' ? ' ' : fBtn.value;
    pvTitles.forEach(function (n) { n.textContent = t; });
    pvDescs.forEach(function (n) { n.textContent = ds; });
    pvBtns.forEach(function (n) { n.textContent = b; });
  }
  function onEdit(field) {
    renderSite();
    clearTimeout(sayT);
    sayT = setTimeout(function () {
      say(EN ? 'Preview updated' : 'Предпросмотр обновлён');
      track('web_demo_content_edit', { tab: 'content', field: field });
    }, 700);
  }
  fTitle.addEventListener('input', function () { onEdit('title'); });
  fDesc.addEventListener('input', function () { onEdit('desc'); });
  fBtn.addEventListener('input', function () { onEdit('btn'); });

  /* ============ вкладка «Адаптив»: размер области просмотра ============ */
  var vp = root.querySelector('#ndpVp');
  var devBtns = Array.prototype.slice.call(root.querySelectorAll('.ndp-dev'));
  devBtns.forEach(function (b) {
    b.addEventListener('click', function () {
      var mode = b.getAttribute('data-mode');
      if (vp.getAttribute('data-mode') === mode) return;
      vp.setAttribute('data-mode', mode);
      devBtns.forEach(function (x) {
        x.setAttribute('aria-pressed', x === b ? 'true' : 'false');
      });
      say((EN ? 'Preview mode: ' : 'Предпросмотр: режим ') + b.querySelector('.ndp-dev-txt').textContent);
      track('web_demo_viewport', { tab: 'adapt', mode: mode });
    });
  });
})();
