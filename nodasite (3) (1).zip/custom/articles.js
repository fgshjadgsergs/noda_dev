/* ============================================================
   NODA · Единый блок статей (ArticleSection / ArticleCard).
   Источник данных — существующий каталог /blog/articles.js
   (window.NODA_BLOG). Подбор: закреплённые статьи в заданном
   порядке → материалы темы страницы по дате → явно заданные
   редактором смежные материалы. Лимит подборки — две карточки,
   дубли исключаются.

   Редактирование подборок: секция NJ_PAGES ниже (описание,
   pinned, tag, related). Тексты и даты статей берутся только
   из /blog/articles.js — здесь они не дублируются.
   ============================================================ */
(function () {
  'use strict';

  var MONTHS = ['января', 'февраля', 'марта', 'апреля', 'мая', 'июня', 'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря'];

  /* контексты страниц: описание + правила подбора.
     related — смежные материалы, явно заданные редактором. */
  var NJ_PAGES = {
    '/': {
      page: 'home',
      desc: 'Разбираем автоматизацию, ИИ и разработку на понятных бизнес-задачах.',
      pinned: ['analitika-dannyh-v-biznese', 'ii-ili-obychnyj-soft']
    },
    '/uslugi/': {
      page: 'uslugi',
      desc: 'Разбираем автоматизацию, ИИ и разработку на понятных бизнес-задачах.',
      pinned: ['analitika-dannyh-v-biznese', 'ii-ili-obychnyj-soft']
    },
    '/uslugi/vnedrenie-ii/': {
      page: 'vnedrenie-ii',
      desc: 'Как выбрать решение, оценить расходы и подготовиться к внедрению.',
      pinned: ['ii-ili-obychnyj-soft', 'kak-vnedrit-ii-v-biznes']
    },
    '/uslugi/sajty-i-prilozheniya/': {
      page: 'sajty-i-prilozheniya',
      desc: 'Как продумать структуру, оценить разработку и подготовить сайт к запуску.',
      related: ['analitika-dannyh-v-biznese', 'crm-bez-haosa']
    },
    '/uslugi/telegram-boty/': {
      page: 'telegram-boty',
      desc: 'Как выбрать сценарий бота, продумать диалог и связать его с работой команды.',
      tag: 'Telegram-боты',
      related: ['crm-bez-haosa']
    },
    '/uslugi/crm/': {
      page: 'crm',
      desc: 'Как выстроить работу с заявками, выбрать CRM и подготовить внедрение.',
      tag: 'CRM',
      related: ['telegram-bot-dlya-prodazh']
    },
    '/uslugi/analitika/': {
      page: 'analitika',
      desc: 'Какие показатели считать, как собрать данные и использовать их в решениях.',
      tag: 'Аналитика',
      related: ['crm-bez-haosa']
    }
  };

  function pagePath() {
    var p = location.pathname.replace(/index\.html$/, '');
    if (p.charAt(p.length - 1) !== '/') p += '/';
    return p;
  }
  function fdate(iso) {
    var p = String(iso || '').split('-');
    if (p.length !== 3) return '';
    return (+p[2]) + ' ' + MONTHS[+p[1] - 1] + ' ' + p[0];
  }
  function esc(s) {
    return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }
  function track(name, params) {
    try {
      if (typeof window.ym === 'function') window.ym(110366569, 'reachGoal', name, params || {});
    } catch (e) { }
  }
  function valid(a) {
    return a && a.slug && a.title && a.date;
  }
  function byDateDesc(a, b) {
    return a.date === b.date ? (a.slug < b.slug ? -1 : 1) : (a.date < b.date ? 1 : -1);
  }

  /* подбор материалов: pinned → тема по дате → related по дате; без дублей */
  function pick(cfg, excludeSlug) {
    var list = (window.NODA_BLOG || []).filter(valid);
    var used = {}, out = [];
    function add(a) {
      if (!a || used[a.slug] || a.slug === excludeSlug || out.length >= 2) return;
      used[a.slug] = 1;
      out.push(a);
    }
    (cfg.pinned || []).forEach(function (slug) {
      add(list.filter(function (a) { return a.slug === slug; })[0]);
    });
    if (cfg.tag) {
      list.filter(function (a) { return a.tag === cfg.tag; }).sort(byDateDesc).forEach(add);
    }
    (cfg.related || []).forEach(function (slug) {
      add(list.filter(function (a) { return a.slug === slug; })[0]);
    });
    return out;
  }

  function cardHTML(a) {
    var meta = '<span>' + esc(a.tag) + '</span>';
    if (a.mins) meta += '<i aria-hidden="true"></i><span>' + a.mins + ' мин чтения</span>';
    var cover = a.cover
      ? '<div class="nj-cover"><img src="' + esc(a.cover) + '" alt="" loading="lazy" onerror="this.parentNode.className=\'nj-cover nj-cover--empty\';this.remove()"/></div>'
      : '<div class="nj-cover nj-cover--empty" aria-hidden="true"></div>';
    return '<article class="nj-card">' +
      '<div class="nj-body">' +
        '<div class="nj-meta">' + meta + '</div>' +
        '<h3 class="nj-title"><a href="/blog/' + esc(a.slug) + '/" data-nj-slug="' + esc(a.slug) + '">' + esc(a.title) + '</a></h3>' +
        '<p class="nj-anons">' + esc(a.desc || '') + '</p>' +
        '<div class="nj-foot">' +
          '<span class="nj-read" aria-hidden="true">Читать статью <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg></span>' +
          '<span class="nj-date">' + fdate(a.date) + '</span>' +
        '</div>' +
      '</div>' + cover +
    '</article>';
  }

  function sectionHTML(cfg, items, num) {
    var kicker = (num ? esc(num) + ' / ' : '') + 'Журнал NODA';
    return '<div class="wrap">' +
      '<div class="nj-head">' +
        '<div class="nj-head-txt">' +
          '<span class="nj-kicker">' + kicker + '</span>' +
          '<h2 class="nj-h2">Разбираем подход<br/><em>в деталях</em></h2>' +
          '<p class="nj-desc">' + esc(cfg.desc || '') + '</p>' +
        '</div>' +
        '<a class="nj-more" href="/blog/" data-nj-more="1">Больше статей <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg></a>' +
      '</div>' +
      '<div class="nj-grid">' + items.map(cardHTML).join('') + '</div>' +
    '</div>';
  }

  function bindAnalytics(sec, cfg) {
    sec.addEventListener('click', function (e) {
      var a = e.target.closest && e.target.closest('a');
      if (!a) return;
      if (a.getAttribute('data-nj-more')) track('nj_blog_open', { page: cfg.page });
      else if (a.getAttribute('data-nj-slug')) track('nj_article_open', { slug: a.getAttribute('data-nj-slug'), page: cfg.page });
    });
  }

  /* публичный интерфейс компонента */
  window.NODA_ARTICLES = {
    configFor: function (path) { return NJ_PAGES[path || pagePath()] || null; },
    pick: pick,
    cardHTML: cardHTML,
    fdate: fdate,

    /* построить секцию подборки (или null, если материалов нет) */
    build: function (cfg, opts) {
      opts = opts || {};
      var items = pick(cfg, opts.excludeSlug);
      if (!items.length) return null;
      var sec = document.createElement('section');
      sec.className = 'nj-sec';
      sec.id = opts.id || 'blog-home';
      sec.innerHTML = sectionHTML(cfg, items, opts.num);
      bindAnalytics(sec, cfg);
      return sec;
    },

    /* обновить статически свёрстанную секцию свежими данными каталога */
    hydrate: function () {
      var sec = document.querySelector('.nj-sec[data-nj-static]');
      if (!sec || !(window.NODA_BLOG || []).length) return;
      var cfg = NJ_PAGES[pagePath()];
      if (!cfg) return;
      var items = pick(cfg);
      if (!items.length) return;
      sec.innerHTML = sectionHTML(cfg, items, sec.getAttribute('data-nj-num') || '');
      bindAnalytics(sec, cfg);
    },

    /* вставить подборку на страницу (для динамических страниц) */
    mount: function (beforeNode, num) {
      if (document.querySelector('.nj-sec')) return;
      var cfg = NJ_PAGES[pagePath()];
      if (!cfg || !beforeNode || !beforeNode.parentNode) return;
      var sec = this.build(cfg, { num: num });
      if (sec) beforeNode.parentNode.insertBefore(sec, beforeNode);
    }
  };

  /* на страницах со статической секцией: догрузить каталог и обновить карточки */
  if (document.querySelector('.nj-sec[data-nj-static]')) {
    if (window.NODA_BLOG) {
      NODA_ARTICLES.hydrate();
    } else {
      var s = document.createElement('script');
      s.src = '/blog/articles.js';
      s.onload = function () { NODA_ARTICLES.hydrate(); };
      document.head.appendChild(s);
    }
  }
})();
