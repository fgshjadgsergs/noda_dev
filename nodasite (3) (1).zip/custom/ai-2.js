/* ============================================================
   NODA · Логика новых блоков страницы «Внедрение ИИ»
   (B1 демо-сценарии, B3 этапы, B4 форма, футер).
   Подключается только на этой странице; ванильный JS без
   библиотек. Демо работают локально на учебных данных и не
   выполняют внешних запросов; настоящая заявка уходит POST
   в /mail.php. Обработчики ограничены новыми компонентами.
   ============================================================ */
(function () {
  'use strict';

  var reducedMotion = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ---------- аналитика: только существующая Метрика ---------- */
  var YM_ID = 110366569;
  function track(name, params) {
    try {
      if (typeof window.ym === 'function') window.ym(YM_ID, 'reachGoal', name, params || {});
    } catch (e) { /* аналитика не должна ломать интерфейс */ }
  }

  /* ---------- плавная прокрутка к якорям ---------- */
  if (!reducedMotion) document.documentElement.style.scrollBehavior = 'smooth';

  /* ---------- фон шапки при прокрутке ---------- */
  var navEl = document.getElementById('nav');
  if (navEl) {
    var onScroll = function () { navEl.classList.toggle('scrolled', window.scrollY > 8); };
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
  }

  /* ---------- мобильное меню (бургер) ---------- */
  var burger = document.querySelector('.nav-burger');
  function closeMenu() {
    document.body.classList.remove('menu-open');
    if (navEl) navEl.classList.remove('menu-open');
    if (burger) burger.setAttribute('aria-expanded', 'false');
  }
  if (burger) {
    burger.addEventListener('click', function () {
      var open = document.body.classList.toggle('menu-open');
      if (navEl) navEl.classList.toggle('menu-open', open);
      burger.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
    document.querySelectorAll('.mobile-menu a').forEach(function (a) {
      a.addEventListener('click', closeMenu);
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') closeMenu();
    });
  }

  /* ---------- фон hero: живая «нейросеть» (порт исходного рендерера) ----------
     Точный перенос 2D-анимации из прежней React-сборки сайта: слои узлов,
     связи, летящие импульсы, свечение и параллакс от курсора. Работает на
     ширинах от 768px; на телефонах остаётся статичная SVG-подложка
     апгрейд-слоя, как на действующем сайте. Канвас имеет собственный id,
     чтобы апгрейд-слой не замораживал его контекст. */
  (function heroNeural() {
    var canvas = document.getElementById('aiNeural');
    if (!canvas || !canvas.getContext) return;
    var ctx = canvas.getContext('2d');
    if (!ctx) return;

    var started = false;
    function wide() { return matchMedia('(min-width: 768px)').matches; }

    var PAL = [[139, 124, 255], [90, 200, 255], [59, 224, 224]];
    var W, H, dpr, layers, pulses;
    var ex = .5, ey = .5, tx = .5, ty = .5;

    function pulseColor(t) {
      var i = Math.min(PAL.length - 2, Math.floor(t * (PAL.length - 1)));
      var k = t * (PAL.length - 1) - i;
      var a = PAL[i], b = PAL[i + 1];
      return [a[0] + (b[0] - a[0]) * k, a[1] + (b[1] - a[1]) * k, a[2] + (b[2] - a[2]) * k];
    }
    function newPulse() {
      return {
        li: 0,
        from: Math.floor(Math.random() * layers[0].length),
        to: Math.floor(Math.random() * layers[1].length),
        t: Math.random(),
        speed: .006 + .01 * Math.random(),
        col: pulseColor(Math.random())
      };
    }
    function build() {
      dpr = Math.min(devicePixelRatio || 1, 1.5);
      var r = canvas.getBoundingClientRect();
      W = canvas.width = Math.max(1, r.width * dpr);
      H = canvas.height = Math.max(1, r.height * dpr);
      var counts = [5, 9, 10, 8, 5];
      layers = [.44, .57, .69, .81, .93].map(function (fx, li) {
        var n = counts[li], arr = [];
        for (var i = 0; i < n; i++) {
          var fy = .18 + .64 * (n === 1 ? .5 : i / (n - 1));
          arr.push({ x: fx * W, y: (fy + .02 * Math.sin(12.9 * i + 3.1 * li)) * H, glow: 0 });
        }
        return arr;
      });
      pulses = [];
      for (var p = 0; p < 28; p++) pulses.push(newPulse());
    }

    var inView = true;
    if ('IntersectionObserver' in window) {
      try {
        new IntersectionObserver(function (en) { inView = en[en.length - 1].isIntersecting; }, { rootMargin: '220px' }).observe(canvas);
      } catch (e) { }
    }

    function frame() {
      requestAnimationFrame(frame);
      if (!wide() || !inView || document.hidden) return;
      ex += (tx - ex) * .04;
      ey += (ty - ey) * .04;
      var ox = (ex - .5) * 30 * dpr, oy = (ey - .5) * 22 * dpr;
      ctx.clearRect(0, 0, W, H);
      for (var li = 0; li < layers.length - 1; li++) {
        for (var a = 0; a < layers[li].length; a++) for (var b = 0; b < layers[li + 1].length; b++) {
          var n1 = layers[li][a], n2 = layers[li + 1][b];
          ctx.strokeStyle = 'rgba(124,150,255,0.09)';
          ctx.lineWidth = dpr;
          ctx.beginPath();
          ctx.moveTo(n1.x + ox, n1.y + oy);
          ctx.lineTo(n2.x + ox, n2.y + oy);
          ctx.stroke();
        }
      }
      pulses.forEach(function (p) {
        p.t += p.speed;
        if (p.t >= 1) {
          p.li++;
          if (p.li >= layers.length - 1) { Object.assign(p, newPulse()); return; }
          p.from = p.to;
          p.to = Math.floor(Math.random() * layers[p.li + 1].length);
          p.t = 0;
          layers[p.li][p.from].glow = 1;
        }
        var n1 = layers[p.li][p.from], n2 = layers[p.li + 1] && layers[p.li + 1][p.to];
        if (!n1 || !n2) { Object.assign(p, newPulse()); return; }
        var px = n1.x + (n2.x - n1.x) * p.t + ox, py = n1.y + (n2.y - n1.y) * p.t + oy;
        var c = p.col, m = Math.max(0, p.t - .12);
        ctx.strokeStyle = 'rgba(' + c[0] + ',' + c[1] + ',' + c[2] + ',0.5)';
        ctx.lineWidth = 1.6 * dpr;
        ctx.beginPath();
        ctx.moveTo(n1.x + (n2.x - n1.x) * m + ox, n1.y + (n2.y - n1.y) * m + oy);
        ctx.lineTo(px, py);
        ctx.stroke();
        ctx.fillStyle = 'rgba(' + c[0] + ',' + c[1] + ',' + c[2] + ',0.95)';
        ctx.beginPath();
        ctx.arc(px, py, 2.6 * dpr, 0, 7);
        ctx.fill();
      });
      layers.forEach(function (layer) {
        layer.forEach(function (n) {
          n.glow *= .94;
          var s = (3 + 4 * n.glow) * dpr;
          var g = ctx.createRadialGradient(n.x + ox, n.y + oy, 0, n.x + ox, n.y + oy, 3 * s);
          g.addColorStop(0, 'rgba(170,190,255,' + (.5 + .5 * n.glow) + ')');
          g.addColorStop(1, 'rgba(170,190,255,0)');
          ctx.fillStyle = g;
          ctx.beginPath();
          ctx.arc(n.x + ox, n.y + oy, 3 * s, 0, 7);
          ctx.fill();
          ctx.fillStyle = 'rgba(205,218,255,' + (.7 + .3 * n.glow) + ')';
          ctx.beginPath();
          ctx.arc(n.x + ox, n.y + oy, .6 * s, 0, 7);
          ctx.fill();
        });
      });
    }

    function start() {
      if (started) return;
      started = true;
      build();
      addEventListener('mousemove', function (e) {
        tx = e.clientX / innerWidth;
        ty = e.clientY / innerHeight;
      });
      var rt;
      addEventListener('resize', function () { clearTimeout(rt); rt = setTimeout(build, 200); });
      requestAnimationFrame(frame);
    }
    if (wide()) start();
    else addEventListener('resize', function () { if (wide()) start(); });
  })();

  /* ---------- появление секций при прокрутке ---------- */
  var revealed = document.querySelectorAll('.ai-rev');
  if (reducedMotion || !('IntersectionObserver' in window)) {
    revealed.forEach(function (el) { el.classList.add('ai-in'); });
  } else {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting) { en.target.classList.add('ai-in'); io.unobserve(en.target); }
      });
    }, { rootMargin: '0px 0px -8% 0px', threshold: 0.05 });
    revealed.forEach(function (el) { io.observe(el); });
  }

  /* ============================================================
     Вкладки: B1 (горизонтальные, стрелки влево/вправо)
     и B3 (вертикальные, стрелки вверх/вниз); Home/End.
     ============================================================ */
  function initTabs(list, vertical, onSelect) {
    if (!list) return;
    var tabs = Array.prototype.slice.call(list.querySelectorAll('[role="tab"]'));
    function select(tab, byUser) {
      tabs.forEach(function (t) {
        var on = t === tab;
        t.setAttribute('aria-selected', on ? 'true' : 'false');
        t.tabIndex = on ? 0 : -1;
      });
      onSelect(tab, byUser);
    }
    tabs.forEach(function (t) {
      t.addEventListener('click', function () { select(t, true); });
    });
    list.addEventListener('keydown', function (e) {
      var i = tabs.indexOf(document.activeElement);
      if (i < 0) return;
      var next = null;
      if ((vertical && e.key === 'ArrowDown') || (!vertical && e.key === 'ArrowRight')) next = tabs[(i + 1) % tabs.length];
      else if ((vertical && e.key === 'ArrowUp') || (!vertical && e.key === 'ArrowLeft')) next = tabs[(i - 1 + tabs.length) % tabs.length];
      else if (e.key === 'Home') next = tabs[0];
      else if (e.key === 'End') next = tabs[tabs.length - 1];
      if (next) { e.preventDefault(); next.focus(); select(next, true); }
    });
  }

  /* ---------- B1: переключение сценариев ---------- */
  initTabs(document.querySelector('.ai-tabs[role="tablist"]'), false, function (tab, byUser) {
    document.querySelectorAll('.ai-practice .ai-panel').forEach(function (p) {
      p.hidden = p.id !== tab.getAttribute('aria-controls');
    });
    if (byUser) track('ai_demo_select', { scenario: tab.getAttribute('data-ai-tab') });
  });

  /* ---------- B1 · сценарий 1: ответы клиентам ---------- */
  (function chatDemo() {
    var qEl = document.getElementById('aiChatQ');
    if (!qEl) return;
    var aEl = document.getElementById('aiChatA');
    var srcBtn = document.getElementById('aiSrcBtn');
    var srcBtnTxt = document.getElementById('aiSrcBtnTxt');
    var srcCard = document.getElementById('aiSrcCard');
    var srcTxt = document.getElementById('aiSrcTxt');
    var handoff = document.getElementById('aiHandoff');
    var status = document.getElementById('aiChatStatus');
    var QA = {
      delivery: {
        q: 'За сколько дней доставите заказ?',
        a: 'Курьерская доставка занимает 2–3 рабочих дня после комплектации заказа.',
        srcBtn: 'Условия доставки · п. 3.2',
        src: '3.2. Курьерская доставка: 2–3 рабочих дня после комплектации заказа. Срочная доставка согласовывается отдельно.',
        status: 'Ответ опирается на конкретный пункт документа'
      },
      pickup: {
        q: 'Можно забрать заказ самостоятельно?',
        a: 'Да, самовывоз бесплатный. Забрать заказ можно после сообщения о его готовности.',
        srcBtn: 'Условия доставки · п. 3.1',
        src: '3.1. Самовывоз бесплатный. Заказ выдают после уведомления покупателя о готовности.',
        status: 'Ответ опирается на конкретный пункт документа'
      },
      today: {
        q: 'А можете гарантировать доставку сегодня?',
        a: 'В материалах нет подтверждения доставки сегодня. Этот вопрос нужно уточнить у сотрудника — подготовлю ему обращение.',
        srcBtn: null,
        src: null,
        status: 'В демо вопрос передан человеку. Внешняя отправка не выполняется.'
      }
    };
    function closeSrc() {
      srcCard.hidden = true;
      srcBtn.setAttribute('aria-expanded', 'false');
    }
    srcBtn.addEventListener('click', function () {
      var open = srcCard.hidden;
      srcCard.hidden = !open;
      srcBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
      track('ai_demo_action', { scenario: 'support', action: open ? 'source_open' : 'source_close' });
    });
    document.querySelectorAll('.ai-q-btn').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var key = btn.getAttribute('data-ai-q');
        var d = QA[key];
        if (!d) return;
        document.querySelectorAll('.ai-q-btn').forEach(function (b) {
          b.setAttribute('aria-pressed', b === btn ? 'true' : 'false');
        });
        qEl.textContent = d.q;
        aEl.textContent = d.a;
        closeSrc();
        if (d.srcBtn) {
          srcBtn.hidden = false;
          srcBtnTxt.textContent = d.srcBtn;
          srcTxt.textContent = d.src;
          handoff.hidden = true;
          status.classList.remove('ai-amberline');
        } else {
          srcBtn.hidden = true;
          handoff.hidden = false;
          status.classList.add('ai-amberline');
        }
        status.textContent = d.status;
        track('ai_demo_action', { scenario: 'support', action: 'question_' + key });
      });
    });
  })();

  /* ---------- B1 · сценарий 2: разбор документов ---------- */
  (function parseDemo() {
    var btn = document.getElementById('aiParseBtn');
    if (!btn) return;
    var hint = document.getElementById('aiParseHint');
    var fields = {
      num: document.querySelector('[data-ai-field="num"]'),
      vendor: document.querySelector('[data-ai-field="vendor"]'),
      sum: document.querySelector('[data-ai-field="sum"]'),
      due: document.querySelector('[data-ai-field="due"]')
    };
    var parsed = false;
    btn.addEventListener('click', function () {
      parsed = !parsed;
      if (parsed) {
        fields.num.querySelector('b').textContent = '104';
        fields.vendor.querySelector('b').textContent = 'ООО «Пример»';
        fields.sum.querySelector('b').textContent = '24 000 ₽';
        fields.due.querySelector('b').textContent = 'Не указан — проверить';
        fields.num.setAttribute('data-state', 'filled');
        fields.vendor.setAttribute('data-state', 'filled');
        fields.sum.setAttribute('data-state', 'filled');
        fields.due.setAttribute('data-state', 'check');
        btn.textContent = 'Сбросить пример';
        hint.textContent = 'Три поля заполнены. Срок оплаты нужно уточнить у поставщика.';
        track('ai_demo_action', { scenario: 'documents', action: 'parse' });
      } else {
        Object.keys(fields).forEach(function (k) {
          fields[k].querySelector('b').textContent = '—';
          fields[k].removeAttribute('data-state');
        });
        btn.textContent = 'Разобрать пример';
        hint.textContent = 'Нажмите, чтобы увидеть результат.';
        track('ai_demo_action', { scenario: 'documents', action: 'reset' });
      }
    });
  })();

  /* ---------- B1 · сценарий 3: действия в CRM ---------- */
  (function crmDemo() {
    var btn = document.getElementById('aiConfirmBtn');
    if (!btn) return;
    var status = document.getElementById('aiActStatus');
    var foot = document.getElementById('aiActFoot');
    var done = false;
    btn.addEventListener('click', function () {
      done = !done;
      if (done) {
        status.textContent = 'Задача создана в демо';
        status.setAttribute('data-done', '1');
        btn.textContent = 'Повторить пример';
        foot.textContent = 'Подтверждение записано в демо. Реальная CRM не подключена.';
        foot.classList.remove('ai-amberline');
        track('ai_demo_action', { scenario: 'actions', action: 'confirm' });
      } else {
        status.textContent = 'Ожидает подтверждения';
        status.removeAttribute('data-done');
        btn.textContent = 'Подтвердить действие';
        foot.textContent = 'До подтверждения задача не создаётся';
        foot.classList.add('ai-amberline');
        track('ai_demo_action', { scenario: 'actions', action: 'repeat' });
      }
    });
  })();

  /* ---------- B3: этапы пилота ---------- */
  var AI_STEPS = {
    1: {
      num: '01 — 03',
      kicker: 'РЕЗУЛЬТАТ ПЕРВОГО ЭТАПА',
      title: 'Паспорт пилота',
      note: 'Общее понимание задачи до начала разработки.',
      rows: [['Задача', 'Один рабочий сценарий'], ['Данные', 'Источники и ограничения'], ['Критерии', 'Что считаем полезным результатом'], ['Рамки', 'Объём, срок и стоимость']],
      foot: 'Вы понимаете, что именно будем проверять'
    },
    2: {
      num: '02 — 03',
      kicker: 'РЕЗУЛЬТАТ ВТОРОГО ЭТАПА',
      title: 'Отчёт по пилоту',
      note: 'Рабочий сценарий и результаты проверки на ваших примерах.',
      rows: [['Качество', 'Ответы, ошибки и исправления'], ['Время', 'Сравнение с ручной работой'], ['Расходы', 'Стоимость работы сценария'], ['Решение', 'Внедрять, изменить или остановить']],
      foot: 'Вы принимаете решение на основе проверки'
    },
    3: {
      num: '03 — 03',
      kicker: 'РЕЗУЛЬТАТ ТРЕТЬЕГО ЭТАПА',
      title: 'Система в работе',
      note: 'Согласованный сценарий встроен в рабочий процесс.',
      rows: [['Связи', 'Нужные каналы и интеграции'], ['Контроль', 'Права, проверки и журнал действий'], ['Команда', 'Инструкции и обучение'], ['Поддержка', 'Правила обновления и развития']],
      foot: 'Команда знает, как пользоваться системой'
    }
  };
  initTabs(document.querySelector('.ai-steps[role="tablist"]'), true, function (tab, byUser) {
    var d = AI_STEPS[tab.getAttribute('data-ai-step')];
    if (!d) return;
    document.getElementById('aiDocNum').textContent = d.num;
    document.getElementById('aiDocKicker').textContent = d.kicker;
    document.getElementById('aiDocTitle').textContent = d.title;
    document.getElementById('aiDocNote').textContent = d.note;
    var rows = document.getElementById('aiDocRows');
    rows.textContent = '';
    d.rows.forEach(function (r) {
      var div = document.createElement('div');
      div.className = 'ai-doc-row';
      var dt = document.createElement('dt'); dt.textContent = r[0];
      var dd = document.createElement('dd'); dd.textContent = r[1];
      div.appendChild(dt); div.appendChild(dd);
      rows.appendChild(div);
    });
    document.getElementById('aiDocFoot').textContent = d.foot;
    document.getElementById('aiDoc').setAttribute('aria-labelledby', tab.id);
    if (byUser) track('ai_pilot_step', { step: Number(tab.getAttribute('data-ai-step')) });
  });

  /* ---------- ссылки «Хочу такой сценарий» и контакты ---------- */
  document.querySelectorAll('[data-ai-interest]').forEach(function (a) {
    a.addEventListener('click', function () {
      var v = a.getAttribute('data-ai-interest');
      var input = document.querySelector('#aiChips input[value="' + v + '"]');
      if (input) input.checked = true;
      track('ai_contact_click', { origin: 'scenario', scenario: a.getAttribute('data-ai-scn') });
    });
  });
  document.querySelectorAll('[data-ai-contact]').forEach(function (a) {
    a.addEventListener('click', function () {
      track('ai_contact_click', {
        origin: a.closest('.ai-foot') ? 'footer' : 'contact_block'
      });
    });
  });

  /* ============================================================
     B4 · Реальная отправка формы в /mail.php
     ============================================================ */
  (function leadForm() {
    var form = document.getElementById('aiLeadForm');
    if (!form) return;
    var btn = document.getElementById('aiSubmit');
    var btnTxt = document.getElementById('aiSubmitTxt');
    var note = document.getElementById('aiFormNote');
    var contact = document.getElementById('aiContact');
    var contactGroup = document.getElementById('aiContactGroup');
    var contactErr = document.getElementById('aiContactErr');
    var busy = false, sent = false;

    function getInterest() {
      var r = form.querySelector('input[name="interest"]:checked');
      return r ? r.value : 'Нужен совет';
    }
    function setBusy(on) {
      busy = on;
      btn.disabled = on || sent;
      btn.setAttribute('data-busy', on ? '1' : '0');
      btnTxt.textContent = on ? 'Отправляем…' : (sent ? 'Заявка отправлена' : 'Обсудить проект');
    }
    function showError(html) {
      note.classList.add('ai-note-err');
      note.innerHTML = html;
      var a = note.querySelector('a');
      if (a) a.addEventListener('click', function () {
        track('ai_contact_click', { origin: 'form_error' });
      });
    }
    function clearNote() {
      note.classList.remove('ai-note-err');
      note.textContent = '';
    }
    function rid() {
      return 'ai-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 10);
    }

    contact.addEventListener('input', function () {
      if (contact.value.trim() !== '') {
        contactGroup.classList.remove('ai-err');
        contactErr.hidden = true;
        contact.removeAttribute('aria-invalid');
      }
    });

    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (busy || sent) return;
      clearNote();

      var contactVal = contact.value.trim();
      if (contactVal === '') {
        contactGroup.classList.add('ai-err');
        contactErr.hidden = false;
        contact.setAttribute('aria-invalid', 'true');
        contact.focus();
        return;
      }

      var name = (document.getElementById('aiName').value || '').trim().slice(0, 80);
      var desc = (document.getElementById('aiDesc').value || '').trim().slice(0, 3000);
      var interest = getInterest();
      var page = location.origin + location.pathname;

      var lines = ['Заявка с сайта NODA · Внедрение ИИ'];
      if (name) lines.push('Имя: ' + name);
      lines.push('Контакт: ' + contactVal.slice(0, 120));
      lines.push('Сценарий: ' + interest);
      if (desc) lines.push('Задача: ' + desc);
      lines.push('Источник: Страница внедрения ИИ');
      lines.push('Страница: ' + page);

      var payload = {
        form_id: 'noda_ai_service',
        name: name,
        contact: contactVal.slice(0, 120),
        interest: interest,
        description: desc,
        source: 'Страница внедрения ИИ',
        page: page,
        website: (document.getElementById('aiWebsite').value || ''),
        _rid: rid(),
        _subject: 'Заявка с сайта NODA · Внедрение ИИ',
        message: lines.join('\n')
      };

      setBusy(true);
      var ac = ('AbortController' in window) ? new AbortController() : null;
      var timer = setTimeout(function () { if (ac) ac.abort(); }, 15000);

      fetch('/mail.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
        signal: ac ? ac.signal : undefined
      }).then(function (res) {
        return res.json().catch(function () { return {}; }).then(function (data) {
          return { ok: res.ok, status: res.status, data: data };
        });
      }).then(function (r) {
        clearTimeout(timer);
        if (r.ok && r.data && String(r.data.success) === 'true') {
          sent = true;
          setBusy(false);
          note.textContent = 'Спасибо! Мы получили вашу задачу и свяжемся с вами по указанному контакту.';
          track('ai_lead_success', { source: 'ai_service', scenario: interest });
        } else {
          setBusy(false);
          showError('Не удалось отправить заявку. Попробуйте ещё раз или напишите нам в <a href="https://t.me/noda_development" target="_blank" rel="noopener">Telegram</a>.');
          track('ai_lead_error', { code: r.status === 429 ? 'ratelimit' : 'server' });
        }
      }).catch(function (err) {
        clearTimeout(timer);
        setBusy(false);
        showError('Не удалось отправить заявку. Попробуйте ещё раз или напишите нам в <a href="https://t.me/noda_development" target="_blank" rel="noopener">Telegram</a>.');
        track('ai_lead_error', { code: (err && err.name === 'AbortError') ? 'timeout' : 'network' });
      });
    });
  })();

  /* ---------- F1 · футер ---------- */
  var yearEl = document.getElementById('aiYear');
  if (yearEl) yearEl.textContent = String(new Date().getFullYear());
  function toTop(e) {
    if (e) e.preventDefault();
    window.scrollTo({ top: 0, behavior: reducedMotion ? 'auto' : 'smooth' });
  }
  var topBtn = document.getElementById('aiTop');
  if (topBtn) topBtn.addEventListener('click', toTop);
  var brandTop = document.getElementById('aiBrandTop');
  if (brandTop) brandTop.addEventListener('click', toTop);
})();
