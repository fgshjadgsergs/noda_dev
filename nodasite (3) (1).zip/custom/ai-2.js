/* ============================================================
   NODA · Логика новых блоков страницы «Внедрение ИИ»
   (B1 демо-сценарии, B3 этапы, B4 форма, футер).
   Подключается только на этой странице; ванильный JS без
   библиотек. Демо работают локально на учебных данных и не
   выполняют внешних запросов; настоящая заявка уходит POST
   в /mail.php. Обработчики ограничены новыми компонентами.
   ============================================================ */
(function () {
  'use strict';

  var reducedMotion = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ---------- аналитика: только существующая Метрика ---------- */
  var YM_ID = 110366569;
  function track(name, params) {
    try {
      if (typeof window.ym === 'function') window.ym(YM_ID, 'reachGoal', name, params || {});
    } catch (e) { /* аналитика не должна ломать интерфейс */ }
  }

  /* ---------- плавная прокрутка к якорям ---------- */
  if (!reducedMotion) document.documentElement.style.scrollBehavior = 'smooth';

  /* ---------- фон шапки при прокрутке ---------- */
  var navEl = document.getElementById('nav');
  if (navEl) {
    var onScroll = function () { navEl.classList.toggle('scrolled', window.scrollY > 8); };
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
  }

  /* ---------- мобильное меню (бургер) ---------- */
  var burger = document.querySelector('.nav-burger');
  function closeMenu() {
    document.body.classList.remove('menu-open');
    if (navEl) navEl.classList.remove('menu-open');
    if (burger) burger.setAttribute('aria-expanded', 'false');
  }
  if (burger) {
    burger.addEventListener('click', function () {
      var open = document.body.classList.toggle('menu-open');
      if (navEl) navEl.classList.toggle('menu-open', open);
      burger.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
    document.querySelectorAll('.mobile-menu a').forEach(function (a) {
      a.addEventListener('click', closeMenu);
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') closeMenu();
    });
  }

  /* ---------- появление секций при прокрутке ---------- */
  var revealed = document.querySelectorAll('.ai-rev');
  if (reducedMotion || !('IntersectionObserver' in window)) {
    revealed.forEach(function (el) { el.classList.add('ai-in'); });
  } else {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting) { en.target.classList.add('ai-in'); io.unobserve(en.target); }
      });
    }, { rootMargin: '0px 0px -8% 0px', threshold: 0.05 });
    revealed.forEach(function (el) { io.observe(el); });
  }

  /* ============================================================
     Вкладки: B1 (горизонтальные, стрелки влево/вправо)
     и B3 (вертикальные, стрелки вверх/вниз); Home/End.
     ============================================================ */
  function initTabs(list, vertical, onSelect) {
    if (!list) return;
    var tabs = Array.prototype.slice.call(list.querySelectorAll('[role="tab"]'));
    function select(tab, byUser) {
      tabs.forEach(function (t) {
        var on = t === tab;
        t.setAttribute('aria-selected', on ? 'true' : 'false');
        t.tabIndex = on ? 0 : -1;
      });
      onSelect(tab, byUser);
    }
    tabs.forEach(function (t) {
      t.addEventListener('click', function () { select(t, true); });
    });
    list.addEventListener('keydown', function (e) {
      var i = tabs.indexOf(document.activeElement);
      if (i < 0) return;
      var next = null;
      if ((vertical && e.key === 'ArrowDown') || (!vertical && e.key === 'ArrowRight')) next = tabs[(i + 1) % tabs.length];
      else if ((vertical && e.key === 'ArrowUp') || (!vertical && e.key === 'ArrowLeft')) next = tabs[(i - 1 + tabs.length) % tabs.length];
      else if (e.key === 'Home') next = tabs[0];
      else if (e.key === 'End') next = tabs[tabs.length - 1];
      if (next) { e.preventDefault(); next.focus(); select(next, true); }
    });
  }

  /* ---------- B1: переключение сценариев ---------- */
  initTabs(document.querySelector('.ai-tabs[role="tablist"]'), false, function (tab, byUser) {
    document.querySelectorAll('.ai-practice .ai-panel').forEach(function (p) {
      p.hidden = p.id !== tab.getAttribute('aria-controls');
    });
    if (byUser) track('ai_demo_select', { scenario: tab.getAttribute('data-ai-tab') });
  });

  /* ---------- B1 · сценарий 1: ответы клиентам ---------- */
  (function chatDemo() {
    var qEl = document.getElementById('aiChatQ');
    if (!qEl) return;
    var aEl = document.getElementById('aiChatA');
    var srcBtn = document.getElementById('aiSrcBtn');
    var srcBtnTxt = document.getElementById('aiSrcBtnTxt');
    var srcCard = document.getElementById('aiSrcCard');
    var srcTxt = document.getElementById('aiSrcTxt');
    var handoff = document.getElementById('aiHandoff');
    var status = document.getElementById('aiChatStatus');
    var QA = {
      delivery: {
        q: 'За сколько дней доставите заказ?',
        a: 'Курьерская доставка занимает 2–3 рабочих дня после комплектации заказа.',
        srcBtn: 'Условия доставки · п. 3.2',
        src: '3.2. Курьерская доставка: 2–3 рабочих дня после комплектации заказа. Срочная доставка согласовывается отдельно.',
        status: 'Ответ опирается на конкретный пункт документа'
      },
      pickup: {
        q: 'Можно забрать заказ самостоятельно?',
        a: 'Да, самовывоз бесплатный. Забрать заказ можно после сообщения о его готовности.',
        srcBtn: 'Условия доставки · п. 3.1',
        src: '3.1. Самовывоз бесплатный. Заказ выдают после уведомления покупателя о готовности.',
        status: 'Ответ опирается на конкретный пункт документа'
      },
      today: {
        q: 'А можете гарантировать доставку сегодня?',
        a: 'В материалах нет подтверждения доставки сегодня. Этот вопрос нужно уточнить у сотрудника — подготовлю ему обращение.',
        srcBtn: null,
        src: null,
        status: 'В демо вопрос передан человеку. Внешняя отправка не выполняется.'
      }
    };
    function closeSrc() {
      srcCard.hidden = true;
      srcBtn.setAttribute('aria-expanded', 'false');
    }
    srcBtn.addEventListener('click', function () {
      var open = srcCard.hidden;
      srcCard.hidden = !open;
      srcBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
      track('ai_demo_action', { scenario: 'support', action: open ? 'source_open' : 'source_close' });
    });
    document.querySelectorAll('.ai-q-btn').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var key = btn.getAttribute('data-ai-q');
        var d = QA[key];
        if (!d) return;
        document.querySelectorAll('.ai-q-btn').forEach(function (b) {
          b.setAttribute('aria-pressed', b === btn ? 'true' : 'false');
        });
        qEl.textContent = d.q;
        aEl.textContent = d.a;
        closeSrc();
        if (d.srcBtn) {
          srcBtn.hidden = false;
          srcBtnTxt.textContent = d.srcBtn;
          srcTxt.textContent = d.src;
          handoff.hidden = true;
          status.classList.remove('ai-amberline');
        } else {
          srcBtn.hidden = true;
          handoff.hidden = false;
          status.classList.add('ai-amberline');
        }
        status.textContent = d.status;
        track('ai_demo_action', { scenario: 'support', action: 'question_' + key });
      });
    });
  })();

  /* ---------- B1 · сценарий 2: разбор документов ---------- */
  (function parseDemo() {
    var btn = document.getElementById('aiParseBtn');
    if (!btn) return;
    var hint = document.getElementById('aiParseHint');
    var fields = {
      num: document.querySelector('[data-ai-field="num"]'),
      vendor: document.querySelector('[data-ai-field="vendor"]'),
      sum: document.querySelector('[data-ai-field="sum"]'),
      due: document.querySelector('[data-ai-field="due"]')
    };
    var parsed = false;
    btn.addEventListener('click', function () {
      parsed = !parsed;
      if (parsed) {
        fields.num.querySelector('b').textContent = '104';
        fields.vendor.querySelector('b').textContent = 'ООО «Пример»';
        fields.sum.querySelector('b').textContent = '24 000 ₽';
        fields.due.querySelector('b').textContent = 'Не указан — проверить';
        fields.num.setAttribute('data-state', 'filled');
        fields.vendor.setAttribute('data-state', 'filled');
        fields.sum.setAttribute('data-state', 'filled');
        fields.due.setAttribute('data-state', 'check');
        btn.textContent = 'Сбросить пример';
        hint.textContent = 'Три поля заполнены. Срок оплаты нужно уточнить у поставщика.';
        track('ai_demo_action', { scenario: 'documents', action: 'parse' });
      } else {
        Object.keys(fields).forEach(function (k) {
          fields[k].querySelector('b').textContent = '—';
          fields[k].removeAttribute('data-state');
        });
        btn.textContent = 'Разобрать пример';
        hint.textContent = 'Нажмите, чтобы увидеть результат.';
        track('ai_demo_action', { scenario: 'documents', action: 'reset' });
      }
    });
  })();

  /* ---------- B1 · сценарий 3: действия в CRM ---------- */
  (function crmDemo() {
    var btn = document.getElementById('aiConfirmBtn');
    if (!btn) return;
    var status = document.getElementById('aiActStatus');
    var foot = document.getElementById('aiActFoot');
    var done = false;
    btn.addEventListener('click', function () {
      done = !done;
      if (done) {
        status.textContent = 'Задача создана в демо';
        status.setAttribute('data-done', '1');
        btn.textContent = 'Повторить пример';
        foot.textContent = 'Подтверждение записано в демо. Реальная CRM не подключена.';
        foot.classList.remove('ai-amberline');
        track('ai_demo_action', { scenario: 'actions', action: 'confirm' });
      } else {
        status.textContent = 'Ожидает подтверждения';
        status.removeAttribute('data-done');
        btn.textContent = 'Подтвердить действие';
        foot.textContent = 'До подтверждения задача не создаётся';
        foot.classList.add('ai-amberline');
        track('ai_demo_action', { scenario: 'actions', action: 'repeat' });
      }
    });
  })();

  /* ---------- B3: этапы пилота ---------- */
  var AI_STEPS = {
    1: {
      num: '01 — 03',
      kicker: 'РЕЗУЛЬТАТ ПЕРВОГО ЭТАПА',
      title: 'Паспорт пилота',
      note: 'Общее понимание задачи до начала разработки.',
      rows: [['Задача', 'Один рабочий сценарий'], ['Данные', 'Источники и ограничения'], ['Критерии', 'Что считаем полезным результатом'], ['Рамки', 'Объём, срок и стоимость']],
      foot: 'Вы понимаете, что именно будем проверять'
    },
    2: {
      num: '02 — 03',
      kicker: 'РЕЗУЛЬТАТ ВТОРОГО ЭТАПА',
      title: 'Отчёт по пилоту',
      note: 'Рабочий сценарий и результаты проверки на ваших примерах.',
      rows: [['Качество', 'Ответы, ошибки и исправления'], ['Время', 'Сравнение с ручной работой'], ['Расходы', 'Стоимость работы сценария'], ['Решение', 'Внедрять, изменить или остановить']],
      foot: 'Вы принимаете решение на основе проверки'
    },
    3: {
      num: '03 — 03',
      kicker: 'РЕЗУЛЬТАТ ТРЕТЬЕГО ЭТАПА',
      title: 'Система в работе',
      note: 'Согласованный сценарий встроен в рабочий процесс.',
      rows: [['Связи', 'Нужные каналы и интеграции'], ['Контроль', 'Права, проверки и журнал действий'], ['Команда', 'Инструкции и обучение'], ['Поддержка', 'Правила обновления и развития']],
      foot: 'Команда знает, как пользоваться системой'
    }
  };
  initTabs(document.querySelector('.ai-steps[role="tablist"]'), true, function (tab, byUser) {
    var d = AI_STEPS[tab.getAttribute('data-ai-step')];
    if (!d) return;
    document.getElementById('aiDocNum').textContent = d.num;
    document.getElementById('aiDocKicker').textContent = d.kicker;
    document.getElementById('aiDocTitle').textContent = d.title;
    document.getElementById('aiDocNote').textContent = d.note;
    var rows = document.getElementById('aiDocRows');
    rows.textContent = '';
    d.rows.forEach(function (r) {
      var div = document.createElement('div');
      div.className = 'ai-doc-row';
      var dt = document.createElement('dt'); dt.textContent = r[0];
      var dd = document.createElement('dd'); dd.textContent = r[1];
      div.appendChild(dt); div.appendChild(dd);
      rows.appendChild(div);
    });
    document.getElementById('aiDocFoot').textContent = d.foot;
    document.getElementById('aiDoc').setAttribute('aria-labelledby', tab.id);
    if (byUser) track('ai_pilot_step', { step: Number(tab.getAttribute('data-ai-step')) });
  });

  /* ---------- ссылки «Хочу такой сценарий» и контакты ---------- */
  document.querySelectorAll('[data-ai-interest]').forEach(function (a) {
    a.addEventListener('click', function () {
      var v = a.getAttribute('data-ai-interest');
      var input = document.querySelector('#aiChips input[value="' + v + '"]');
      if (input) input.checked = true;
      track('ai_contact_click', { origin: 'scenario', scenario: a.getAttribute('data-ai-scn') });
    });
  });
  document.querySelectorAll('[data-ai-contact]').forEach(function (a) {
    a.addEventListener('click', function () {
      track('ai_contact_click', {
        origin: a.closest('.ai-foot') ? 'footer' : 'contact_block'
      });
    });
  });

  /* ============================================================
     B4 · Реальная отправка формы в /mail.php
     ============================================================ */
  (function leadForm() {
    var form = document.getElementById('aiLeadForm');
    if (!form) return;
    var btn = document.getElementById('aiSubmit');
    var btnTxt = document.getElementById('aiSubmitTxt');
    var note = document.getElementById('aiFormNote');
    var contact = document.getElementById('aiContact');
    var contactGroup = document.getElementById('aiContactGroup');
    var contactErr = document.getElementById('aiContactErr');
    var busy = false, sent = false;

    function getInterest() {
      var r = form.querySelector('input[name="interest"]:checked');
      return r ? r.value : 'Нужен совет';
    }
    function setBusy(on) {
      busy = on;
      btn.disabled = on || sent;
      btn.setAttribute('data-busy', on ? '1' : '0');
      btnTxt.textContent = on ? 'Отправляем…' : (sent ? 'Заявка отправлена' : 'Обсудить мою задачу ↗');
    }
    function showError(html) {
      note.classList.add('ai-note-err');
      note.innerHTML = html;
      var a = note.querySelector('a');
      if (a) a.addEventListener('click', function () {
        track('ai_contact_click', { origin: 'form_error' });
      });
    }
    function clearNote() {
      note.classList.remove('ai-note-err');
      note.textContent = '';
    }
    function rid() {
      return 'ai-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 10);
    }

    contact.addEventListener('input', function () {
      if (contact.value.trim() !== '') {
        contactGroup.classList.remove('ai-err');
        contactErr.hidden = true;
        contact.removeAttribute('aria-invalid');
      }
    });

    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (busy || sent) return;
      clearNote();

      var contactVal = contact.value.trim();
      if (contactVal === '') {
        contactGroup.classList.add('ai-err');
        contactErr.hidden = false;
        contact.setAttribute('aria-invalid', 'true');
        contact.focus();
        return;
      }

      var name = (document.getElementById('aiName').value || '').trim().slice(0, 80);
      var desc = (document.getElementById('aiDesc').value || '').trim().slice(0, 3000);
      var interest = getInterest();
      var page = location.origin + location.pathname;

      var lines = ['Заявка с сайта NODA · Внедрение ИИ'];
      if (name) lines.push('Имя: ' + name);
      lines.push('Контакт: ' + contactVal.slice(0, 120));
      lines.push('Сценарий: ' + interest);
      if (desc) lines.push('Задача: ' + desc);
      lines.push('Источник: Страница внедрения ИИ');
      lines.push('Страница: ' + page);

      var payload = {
        form_id: 'noda_ai_service',
        name: name,
        contact: contactVal.slice(0, 120),
        interest: interest,
        description: desc,
        source: 'Страница внедрения ИИ',
        page: page,
        website: (document.getElementById('aiWebsite').value || ''),
        _rid: rid(),
        _subject: 'Заявка с сайта NODA · Внедрение ИИ',
        message: lines.join('\n')
      };

      setBusy(true);
      var ac = ('AbortController' in window) ? new AbortController() : null;
      var timer = setTimeout(function () { if (ac) ac.abort(); }, 15000);

      fetch('/mail.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
        signal: ac ? ac.signal : undefined
      }).then(function (res) {
        return res.json().catch(function () { return {}; }).then(function (data) {
          return { ok: res.ok, status: res.status, data: data };
        });
      }).then(function (r) {
        clearTimeout(timer);
        if (r.ok && r.data && String(r.data.success) === 'true') {
          sent = true;
          setBusy(false);
          note.textContent = 'Спасибо! Мы получили вашу задачу и свяжемся с вами по указанному контакту.';
          track('ai_lead_success', { source: 'ai_service', scenario: interest });
        } else {
          setBusy(false);
          showError('Не удалось отправить заявку. Попробуйте ещё раз или напишите нам в <a href="https://t.me/noda_development" target="_blank" rel="noopener">Telegram</a>.');
          track('ai_lead_error', { code: r.status === 429 ? 'ratelimit' : 'server' });
        }
      }).catch(function (err) {
        clearTimeout(timer);
        setBusy(false);
        showError('Не удалось отправить заявку. Попробуйте ещё раз или напишите нам в <a href="https://t.me/noda_development" target="_blank" rel="noopener">Telegram</a>.');
        track('ai_lead_error', { code: (err && err.name === 'AbortError') ? 'timeout' : 'network' });
      });
    });
  })();

  /* ---------- F1 · футер ---------- */
  var yearEl = document.getElementById('aiYear');
  if (yearEl) yearEl.textContent = String(new Date().getFullYear());
  function toTop(e) {
    if (e) e.preventDefault();
    window.scrollTo({ top: 0, behavior: reducedMotion ? 'auto' : 'smooth' });
  }
  var topBtn = document.getElementById('aiTop');
  if (topBtn) topBtn.addEventListener('click', toTop);
  var brandTop = document.getElementById('aiBrandTop');
  if (brandTop) brandTop.addEventListener('click', toTop);
})();
