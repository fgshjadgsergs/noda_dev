/* ============================================================
   NODA · Дополнительный слой поведения страниц услуг:
   модальное окно заявки (по всем кнопкам «оставить заявку»),
   бесшовная бегущая строка технологий, водяной знак номера
   этапа в «документах» и живой «квиток» заявки в форме.
   ============================================================ */
(function () {
  'use strict';

  var reduced = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var YM_ID = 110366569;
  function track(name, params) {
    try {
      if (typeof window.ym === 'function') window.ym(YM_ID, 'reachGoal', name, params || {});
    } catch (e) { }
  }
  var EN = document.documentElement.lang === 'en';
  var T = EN ? {
    modalTitle: 'Tell us about your task',
    modalSub: 'We reply within an hour during business hours — with a plan and a quote.',
    close: 'Close',
    ticket: 'Your request', toManager: 'goes straight to the founders',
    tFormat: 'Format', tInterest: 'Scenario', tTask: 'Task', tName: 'Name', tContact: 'Contact'
  } : {
    modalTitle: 'Расскажите о задаче',
    modalSub: 'Ответим в течение часа в рабочее время — с планом и сметой.',
    close: 'Закрыть',
    ticket: 'Ваша заявка', toManager: 'придёт напрямую разработчикам',
    tFormat: 'Формат', tInterest: 'Сценарий', tTask: 'Задача', tName: 'Имя', tContact: 'Контакт'
  };

  /* ============ модальное окно заявки ============ */
  var leadForm = document.getElementById('wdLeadForm') || document.getElementById('aiLeadForm');
  var modal = null, formHome = null, opener = null;

  function buildModal() {
    if (modal) return modal;
    modal = document.createElement('div');
    modal.className = 'svc-modal';
    modal.hidden = true;
    modal.innerHTML =
      '<div class="svc-modal-ovl"></div>' +
      '<div class="svc-modal-dlg" role="dialog" aria-modal="true" aria-label="' + T.modalTitle + '">' +
        '<div class="svc-modal-head"><div><b>' + T.modalTitle + '</b><p>' + T.modalSub + '</p></div>' +
        '<button class="svc-modal-x" type="button" aria-label="' + T.close + '">' +
          '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg>' +
        '</button></div>' +
        '<div class="svc-modal-body"></div>' +
      '</div>';
    document.body.appendChild(modal);
    modal.querySelector('.svc-modal-ovl').addEventListener('click', closeModal);
    modal.querySelector('.svc-modal-x').addEventListener('click', closeModal);
    modal.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') { closeModal(); return; }
      if (e.key !== 'Tab') return;
      var f = modal.querySelectorAll('button, input, textarea, select, a[href]');
      var list = Array.prototype.filter.call(f, function (el) { return !el.disabled && el.offsetParent !== null; });
      if (!list.length) return;
      var first = list[0], last = list[list.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    });
    return modal;
  }
  function openModal(btn) {
    if (!leadForm) return false;
    buildModal();
    opener = btn || null;
    if (!formHome) {
      formHome = document.createComment('svc-form-home');
      leadForm.parentNode.insertBefore(formHome, leadForm);
    }
    modal.querySelector('.svc-modal-body').appendChild(leadForm);
    modal.hidden = false;
    document.body.classList.add('svc-lock');
    var first = leadForm.querySelector('input:not([type="hidden"]):not([tabindex="-1"]), textarea');
    if (first) first.focus();
    track('web_modal_open', {});
    return true;
  }
  function closeModal() {
    if (!modal || modal.hidden) return;
    modal.hidden = true;
    document.body.classList.remove('svc-lock');
    if (formHome && leadForm) formHome.parentNode.insertBefore(leadForm, formHome.nextSibling);
    if (opener && opener.focus) opener.focus();
    opener = null;
  }
  if (leadForm) {
    document.addEventListener('click', function (e) {
      var a = e.target.closest && e.target.closest('a[href]');
      if (!a) return;
      var href = a.getAttribute('href') || '';
      if (!/#(contact|zayavka)$/.test(href)) return;
      if (modal && modal.contains(a)) return;
      e.preventDefault();
      openModal(a);
    }, true);
  }

  /* ============ бесшовная бегущая строка ============ */
  document.querySelectorAll('.svc-marq-row').forEach(function (row) {
    var trackEl = row.querySelector('.svc-marq-track');
    if (!trackEl) return;
    var guard = 0;
    function fill() {
      var need = row.clientWidth * 2;
      var total = 0;
      row.querySelectorAll('.svc-marq-track').forEach(function (t) { total += t.scrollWidth; });
      while (total < need && guard < 6) {
        var c = trackEl.cloneNode(true);
        c.setAttribute('aria-hidden', 'true');
        row.appendChild(c);
        total += trackEl.scrollWidth;
        guard++;
      }
    }
    fill();
    var rt;
    addEventListener('resize', function () { clearTimeout(rt); rt = setTimeout(fill, 250); });
  });

  /* ============ водяной знак номера этапа в «документах» ============ */
  function watermark(docEl, getNum) {
    if (!docEl) return;
    var wm = document.createElement('span');
    wm.className = 'svc-doc-wm';
    wm.setAttribute('aria-hidden', 'true');
    docEl.appendChild(wm);
    function upd() { wm.textContent = getNum(); }
    upd();
    try {
      new MutationObserver(upd).observe(docEl, { attributes: true, attributeFilter: ['aria-labelledby'], subtree: false, childList: true, characterData: true });
    } catch (e) { }
    return upd;
  }
  var aiDoc = document.getElementById('aiDoc');
  if (aiDoc) {
    var aiNum = document.getElementById('aiDocNum');
    var updAi = watermark(aiDoc, function () {
      var m = /\d+/.exec(aiNum ? aiNum.textContent : '');
      return m ? m[0] : '01';
    });
    if (aiNum && updAi) {
      try { new MutationObserver(updAi).observe(aiNum, { childList: true, characterData: true, subtree: true }); } catch (e) { }
    }
  }
  var wdDoc = document.getElementById('wdDoc');
  if (wdDoc) {
    watermark(wdDoc, function () {
      var m = /\d+/.exec(wdDoc.getAttribute('aria-labelledby') || '');
      return m ? '0' + m[0] : '01';
    });
  }

  /* ============ живой «квиток» заявки в форме ============ */
  (function ticket() {
    if (!leadForm) return;
    var isWd = leadForm.id === 'wdLeadForm';
    var radioName = isWd ? 'format' : 'interest';
    var descEl = document.getElementById(isWd ? 'wdDesc' : 'aiDesc');
    var nameEl = document.getElementById(isWd ? 'wdName' : 'aiName');
    var contactEl = document.getElementById(isWd ? 'wdContact' : 'aiContact');
    var submitBtn = leadForm.querySelector('button[type="submit"]');
    if (!descEl || !contactEl || !submitBtn) return;

    var box = document.createElement('div');
    box.className = 'svc-ticket';
    box.setAttribute('aria-hidden', 'true');
    box.innerHTML =
      '<div class="svc-ticket-top"><span>' + T.ticket + ' · <i>' + T.toManager + '</i></span></div>' +
      '<div class="svc-ticket-rows"></div>' +
      '<div class="svc-ticket-bar"><i></i></div>';
    var host = submitBtn;
    while (host.parentElement && host.parentElement !== leadForm) host = host.parentElement;
    leadForm.insertBefore(box, host);
    var rows = box.querySelector('.svc-ticket-rows');
    var bar = box.querySelector('.svc-ticket-bar i');

    function chip(label, value, on) {
      var s = document.createElement('span');
      s.className = 'svc-tk' + (on ? ' svc-tk-on' : '');
      var i = document.createElement('i');
      i.textContent = label + ':';
      var v = document.createElement('span');
      v.textContent = value;
      s.appendChild(i);
      s.appendChild(v);
      return s;
    }
    function trim(v, n) {
      v = String(v || '').replace(/\s+/g, ' ').trim();
      return v.length > n ? v.slice(0, n - 1) + '…' : v;
    }
    function render() {
      var r = leadForm.querySelector('input[name="' + radioName + '"]:checked');
      var desc = trim(descEl.value, 44);
      var name = nameEl ? trim(nameEl.value, 24) : '';
      var contact = trim(contactEl.value, 26);
      rows.textContent = '';
      rows.appendChild(chip(isWd ? T.tFormat : T.tInterest, r ? r.value : '—', !!r));
      rows.appendChild(chip(T.tTask, desc || '—', !!desc));
      rows.appendChild(chip(T.tName, name || '—', !!name));
      rows.appendChild(chip(T.tContact, contact || '—', !!contact));
      var score = (r ? 1 : 0) + (desc ? 1 : 0) + (name ? 1 : 0) + (contact ? 1 : 0);
      bar.style.width = (score / 4 * 100) + '%';
    }
    leadForm.addEventListener('input', render);
    leadForm.addEventListener('change', render);
    render();
  })();
})();
