/* ============================================================
   NODA · Дополнительный слой поведения страниц услуг:
   модальное окно заявки (по всем кнопкам «оставить заявку»),
   бесшовная бегущая строка технологий, индикатор этапа в
   «паспортах», пошаговая форма заявки (визард) поверх обычной
   формы — без JavaScript остаётся классическая форма.
   ============================================================ */
(function () {
  'use strict';

  var reduced = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var YM_ID = 110366569;
  function track(name, params) {
    try {
      if (typeof window.ym === 'function') window.ym(YM_ID, 'reachGoal', name, params || {});
    } catch (e) { }
  }
  var EN = document.documentElement.lang === 'en';
  var T = EN ? {
    modalTitle: 'Tell us about your task',
    modalSub: 'We reply within an hour during business hours — with a plan and a quote.',
    close: 'Close',
    stepOf: 'Step', of: 'of',
    q1: 'What do you need?', q1s: 'Pick the closest option — we will refine it on the call.',
    q2: 'A few words about the task', q2s: 'Optional: what should we build or improve?',
    q3: 'How can we reach you?', q3s: 'A phone number or Telegram is enough — we reply within an hour.',
    q4: 'Check and send', q4s: 'Everything goes straight to the founders.',
    next: 'Next', skip: 'Skip', back: 'Back', edit: 'Edit',
    enterHint: 'Enter — next step',
    fmt: 'Format', scn: 'Scenario', task: 'Task', name: 'Name', contact: 'Contact', empty: 'not specified',
    stage: 'Stage'
  } : {
    modalTitle: 'Расскажите о задаче',
    modalSub: 'Ответим в течение часа в рабочее время — с планом и сметой.',
    close: 'Закрыть',
    stepOf: 'Шаг', of: 'из',
    q1: 'Что нужно сделать?', q1s: 'Выберите ближайший вариант — уточним на созвоне.',
    q2: 'Пара слов о задаче', q2s: 'Необязательно: что хотите запустить или улучшить?',
    q3: 'Как с вами связаться?', q3s: 'Достаточно телефона или Telegram — ответим в течение часа.',
    q4: 'Проверьте и отправьте', q4s: 'Заявка придёт напрямую разработчикам.',
    next: 'Далее', skip: 'Пропустить', back: 'Назад', edit: 'Изменить',
    enterHint: 'Enter — следующий шаг',
    fmt: 'Формат', scn: 'Сценарий', task: 'Задача', name: 'Имя', contact: 'Контакт', empty: 'не указано',
    stage: 'Этап'
  };

  var leadForm = document.getElementById('wdLeadForm') || document.getElementById('aiLeadForm');
  var isWd = !!(leadForm && leadForm.id === 'wdLeadForm');
  var P = isWd ? 'wd' : 'ai';

  /* ============ модальное окно заявки ============ */
  var modal = null, formHome = null, opener = null;

  function buildModal() {
    if (modal) return modal;
    modal = document.createElement('div');
    modal.className = 'svc-modal';
    modal.hidden = true;
    modal.innerHTML =
      '<div class="svc-modal-ovl"></div>' +
      '<div class="svc-modal-dlg" role="dialog" aria-modal="true" aria-label="' + T.modalTitle + '">' +
        '<div class="svc-modal-head"><div><b>' + T.modalTitle + '</b><p>' + T.modalSub + '</p></div>' +
        '<button class="svc-modal-x" type="button" aria-label="' + T.close + '">' +
          '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg>' +
        '</button></div>' +
        /* обёртка несёт классы секции: в них живут CSS-переменные формы */
        '<div class="svc-modal-body ' + (isWd ? 'wd-sec wd-contact' : 'noda-ai-sections ai-contact') + '"></div>' +
      '</div>';
    document.body.appendChild(modal);
    modal.querySelector('.svc-modal-ovl').addEventListener('click', closeModal);
    modal.querySelector('.svc-modal-x').addEventListener('click', closeModal);
    modal.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') { closeModal(); return; }
      if (e.key !== 'Tab') return;
      var f = modal.querySelectorAll('button, input, textarea, select, a[href]');
      var list = Array.prototype.filter.call(f, function (el) { return !el.disabled && el.offsetParent !== null && el.tabIndex !== -1; });
      if (!list.length) return;
      var first = list[0], last = list[list.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    });
    return modal;
  }
  function openModal(btn) {
    if (!leadForm) return false;
    buildModal();
    opener = btn || null;
    if (!formHome) {
      formHome = document.createComment('svc-form-home');
      leadForm.parentNode.insertBefore(formHome, leadForm);
    }
    modal.querySelector('.svc-modal-body').appendChild(leadForm);
    modal.hidden = false;
    document.body.classList.add('svc-lock');
    if (window.__svcWizardFocus) window.__svcWizardFocus();
    else {
      var first = leadForm.querySelector('input:not([type="hidden"]):not([tabindex="-1"]), textarea');
      if (first) first.focus();
    }
    track('web_modal_open', {});
    return true;
  }
  function closeModal() {
    if (!modal || modal.hidden) return;
    modal.hidden = true;
    document.body.classList.remove('svc-lock');
    if (formHome && leadForm) formHome.parentNode.insertBefore(leadForm, formHome.nextSibling);
    if (opener && opener.focus) opener.focus();
    opener = null;
  }
  if (leadForm) {
    document.addEventListener('click', function (e) {
      var a = e.target.closest && e.target.closest('a[href]');
      if (!a) return;
      var href = a.getAttribute('href') || '';
      if (!/#(contact|zayavka)$/.test(href)) return;
      if (modal && modal.contains(a)) return;
      e.preventDefault();
      openModal(a);
    }, true);
  }

  /* ============ бесшовная бегущая строка ============ */
  document.querySelectorAll('.svc-marq-row').forEach(function (row) {
    var trackEl = row.querySelector('.svc-marq-track');
    if (!trackEl) return;
    var guard = 0;
    function fill() {
      var need = row.clientWidth * 2;
      var total = 0;
      row.querySelectorAll('.svc-marq-track').forEach(function (t) { total += t.scrollWidth; });
      while (total < need && guard < 6) {
        var c = trackEl.cloneNode(true);
        c.setAttribute('aria-hidden', 'true');
        row.appendChild(c);
        total += trackEl.scrollWidth;
        guard++;
      }
    }
    fill();
    var rt;
    addEventListener('resize', function () { clearTimeout(rt); rt = setTimeout(fill, 250); });
  });

  /* ============ «паспорта» этапов: индикатор и водяной знак ============ */
  function decorateDoc(docEl, topSel, getNum) {
    if (!docEl) return;
    var wm = document.createElement('span');
    wm.className = 'svc-doc-wm';
    wm.setAttribute('aria-hidden', 'true');
    docEl.appendChild(wm);
    var steps = document.createElement('div');
    steps.className = 'svc-doc-steps';
    steps.setAttribute('aria-hidden', 'true');
    steps.innerHTML = '<i></i><i></i><i></i><b></b>';
    var top = docEl.querySelector(topSel);
    if (top && top.parentNode === docEl) docEl.insertBefore(steps, top.nextSibling);
    else docEl.insertBefore(steps, docEl.firstChild);
    var bars = steps.querySelectorAll('i');
    var lbl = steps.querySelector('b');
    function upd() {
      var n = parseInt(getNum(), 10) || 1;
      wm.textContent = n < 10 ? '0' + n : String(n);
      bars.forEach(function (b, i) {
        b.className = (i + 1 === n) ? 'on' : (i + 1 < n ? 'done' : '');
      });
      lbl.textContent = T.stage + ' ' + n + ' ' + T.of + ' 3';
    }
    upd();
    return upd;
  }
  var aiDoc = document.getElementById('aiDoc');
  if (aiDoc) {
    var aiNum = document.getElementById('aiDocNum');
    var updAi = decorateDoc(aiDoc, '.ai-doc-top', function () {
      var m = /\d+/.exec(aiNum ? aiNum.textContent : '');
      return m ? m[0] : '1';
    });
    if (aiNum && updAi) {
      try { new MutationObserver(updAi).observe(aiNum, { childList: true, characterData: true, subtree: true }); } catch (e) { }
    }
  }
  var wdDoc = document.getElementById('wdDoc');
  if (wdDoc) {
    var updWd = decorateDoc(wdDoc, '.wd-doc-top', function () {
      var m = /\d+/.exec(wdDoc.getAttribute('aria-labelledby') || '');
      return m ? m[0] : '1';
    });
    try { new MutationObserver(updWd).observe(wdDoc, { attributes: true, attributeFilter: ['aria-labelledby'] }); } catch (e) { }
  }

  /* ============ пошаговая форма заявки (визард) ============ */
  (function wizard() {
    if (!leadForm) return;
    var body = isWd ? leadForm.querySelector('.wd-form-body') : leadForm;
    var chips = leadForm.querySelector('.' + P + '-chips');
    var descFg = leadForm.querySelector('#' + P + 'Desc') && leadForm.querySelector('#' + P + 'Desc').closest('.' + P + '-fg');
    var row2 = leadForm.querySelector('.' + P + '-frow2');
    var submit = leadForm.querySelector('button[type="submit"]');
    var note = leadForm.querySelector('.' + P + '-form-note');
    var consent = leadForm.querySelector('.' + P + '-consent');
    var reqNote = leadForm.querySelector('.' + P + '-req-note');
    var descEl = leadForm.querySelector('#' + P + 'Desc');
    var nameEl = leadForm.querySelector('#' + P + 'Name');
    var contactEl = leadForm.querySelector('#' + P + 'Contact');
    var contactGroup = leadForm.querySelector('#' + P + 'ContactGroup');
    var contactErr = leadForm.querySelector('#' + P + 'ContactErr');
    if (!body || !chips || !descFg || !row2 || !submit || !contactEl) return;

    var radioName = isWd ? 'format' : 'interest';
    var TOTAL = 4, step = 1;

    /* каркас */
    var wz = document.createElement('div');
    wz.className = 'svc-wz';
    var top = document.createElement('div');
    top.className = 'svc-wz-top';
    top.innerHTML = '<span class="svc-wz-step"><b>' + T.stepOf + ' <span data-wz-n>1</span></b> ' + T.of + ' ' + TOTAL + '</span>';
    var bar = document.createElement('div');
    bar.className = 'svc-wz-bar';
    bar.innerHTML = '<i></i>';
    var barFill = bar.querySelector('i');
    var stepN = top.querySelector('[data-wz-n]');

    function pane(q, sub) {
      var d = document.createElement('div');
      d.className = 'svc-wz-pane';
      d.setAttribute('role', 'group');
      var h = document.createElement('p');
      h.className = 'svc-wz-q';
      h.textContent = q;
      var s = document.createElement('small');
      s.textContent = sub;
      h.appendChild(s);
      d.appendChild(h);
      return d;
    }
    function navRow(opts) {
      var n = document.createElement('div');
      n.className = 'svc-wz-nav';
      if (opts.back) {
        var b = document.createElement('button');
        b.type = 'button';
        b.className = 'svc-wz-back';
        b.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" style="width:14px;height:14px"><path d="M19 12H5M11 6l-6 6 6 6"/></svg>' + T.back;
        b.addEventListener('click', function () { go(step - 1, 'back'); });
        n.appendChild(b);
      }
      if (opts.skip) {
        var sk = document.createElement('button');
        sk.type = 'button';
        sk.className = 'svc-wz-back';
        sk.textContent = T.skip;
        sk.addEventListener('click', function () { go(step + 1, 'fwd'); });
        n.appendChild(sk);
      }
      if (opts.next) {
        var nx = document.createElement('button');
        nx.type = 'button';
        nx.className = 'svc-wz-next';
        nx.innerHTML = T.next + ' <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" style="width:14px;height:14px"><path d="M5 12h14M13 6l6 6-6 6"/></svg>';
        nx.addEventListener('click', function () { tryNext(); });
        n.appendChild(nx);
      }
      if (opts.hint) {
        var h = document.createElement('span');
        h.className = 'svc-wz-hint';
        h.innerHTML = '<kbd>Enter</kbd> — ' + (EN ? 'next step' : 'следующий шаг');
        n.appendChild(h);
      }
      return n;
    }

    var p1 = pane(T.q1, T.q1s);
    p1.appendChild(chips);
    p1.appendChild(navRow({ next: true, hint: true }));

    var p2 = pane(T.q2, T.q2s);
    p2.appendChild(descFg);
    p2.appendChild(navRow({ back: true, skip: true, next: true }));

    var p3 = pane(T.q3, T.q3s);
    p3.appendChild(row2);
    p3.appendChild(navRow({ back: true, next: true, hint: true }));

    var p4 = pane(T.q4, T.q4s);
    var sum = document.createElement('div');
    sum.className = 'svc-wz-sum';
    p4.appendChild(sum);
    var nav4 = document.createElement('div');
    nav4.className = 'svc-wz-nav';
    var back4 = document.createElement('button');
    back4.type = 'button';
    back4.className = 'svc-wz-back';
    back4.textContent = T.back;
    back4.addEventListener('click', function () { go(3, 'back'); });
    nav4.appendChild(back4);
    nav4.appendChild(submit);
    p4.appendChild(nav4);
    if (note) p4.appendChild(note);
    if (consent) p4.appendChild(consent);
    if (reqNote) reqNote.classList.add('svc-wz-hidden');

    var panes = [p1, p2, p3, p4];
    wz.appendChild(top);
    wz.appendChild(bar);
    panes.forEach(function (p) { wz.appendChild(p); });
    /* вставить визард на место первого перемещённого элемента */
    var anchor = body.querySelector('.' + P + '-form-head');
    if (anchor && anchor.nextSibling) body.insertBefore(wz, anchor.nextSibling);
    else body.appendChild(wz);

    function esc(s) { return String(s == null ? '' : s); }
    function renderSummary() {
      var r = leadForm.querySelector('input[name="' + radioName + '"]:checked');
      var rows = [
        [isWd ? T.fmt : T.scn, r ? (r.parentNode.querySelector('span') || r).textContent : '', 1],
        [T.task, descEl ? descEl.value.trim() : '', 2],
        [T.name, nameEl ? nameEl.value.trim() : '', 3],
        [T.contact, contactEl.value.trim(), 3]
      ];
      sum.textContent = '';
      rows.forEach(function (row) {
        var d = document.createElement('div');
        d.className = 'svc-wz-sum-row';
        var i = document.createElement('i'); i.textContent = row[0];
        var v = document.createElement('span'); v.textContent = esc(row[1]) || T.empty;
        if (!row[1]) v.style.color = '#B4AFC1';
        var b = document.createElement('button'); b.type = 'button'; b.textContent = T.edit;
        b.addEventListener('click', function () { go(row[2], 'back'); });
        d.appendChild(i); d.appendChild(v); d.appendChild(b);
        sum.appendChild(d);
      });
    }
    function focusStep(dir) {
      var target = null;
      if (step === 1) target = leadForm.querySelector('input[name="' + radioName + '"]:checked') || leadForm.querySelector('input[name="' + radioName + '"]');
      else if (step === 2) target = descEl;
      else if (step === 3) target = (dir === 'back' ? contactEl : (nameEl || contactEl));
      else target = submit;
      if (target && target.focus) {
        try { target.focus({ preventScroll: true }); } catch (e) { target.focus(); }
      }
    }
    function go(n, dir) {
      if (n < 1 || n > TOTAL) return;
      step = n;
      panes.forEach(function (p, i) {
        var on = i + 1 === n;
        p.hidden = !on;
        p.classList.remove('svc-wz-in');
        if (on && !reduced) { void p.offsetWidth; p.classList.add('svc-wz-in'); }
      });
      stepN.textContent = String(n);
      barFill.style.width = Math.round((n - 1) / (TOTAL - 1) * 100) + '%';
      if (n === TOTAL) renderSummary();
      focusStep(dir);
      track('web_wizard_step', { step: n });
    }
    function tryNext() {
      if (step === 3 && contactEl.value.trim() === '') {
        if (contactGroup) contactGroup.classList.add(P + '-err');
        if (contactErr) contactErr.hidden = false;
        contactEl.setAttribute('aria-invalid', 'true');
        contactEl.focus();
        return;
      }
      go(step + 1, 'fwd');
    }
    contactEl.addEventListener('input', function () {
      if (contactEl.value.trim() !== '') {
        if (contactGroup) contactGroup.classList.remove(P + '-err');
        if (contactErr) contactErr.hidden = true;
        contactEl.removeAttribute('aria-invalid');
      }
    });
    /* Enter в текстовых полях — следующий шаг (не отправка) */
    leadForm.addEventListener('keydown', function (e) {
      if (e.key !== 'Enter' || e.target.tagName === 'TEXTAREA' || e.target.tagName === 'BUTTON') return;
      if (step < TOTAL) { e.preventDefault(); tryNext(); }
    });
    /* выбор чипа мышью — сразу дальше */
    chips.addEventListener('change', function () {
      if (step === 1) setTimeout(function () { if (step === 1) go(2, 'fwd'); }, 180);
    });
    /* «Отправить ещё» — вернуться на первый шаг */
    var again = leadForm.querySelector('#' + P + 'Again');
    if (again) again.addEventListener('click', function () { go(1, 'fwd'); });
    /* если пришла ошибка отправки — она в шаге 4, ничего не менять */

    go(1, 'init');
    barFill.style.width = '0%';
    window.__svcWizardFocus = function () { go(step, 'init'); };
  })();
})();
