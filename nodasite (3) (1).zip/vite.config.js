import { defineConfig } from 'vite';

// Local preview of the exported HTML. Production still uses the existing
// static files and PHP endpoints; Vite does not replace that server.
export default defineConfig({
  appType: 'mpa',
  server: {
    host: '0.0.0.0',
    allowedHosts: ['terminal.local'],
    fs: { deny: ['**/*.php', '**/.htaccess', '**/.env*', '**/*.zip'] }
  }
});
