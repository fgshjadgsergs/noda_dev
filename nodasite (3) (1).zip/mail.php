<?php
/* ============================================================
   NODA · приём заявок с сайта.
   Форма отправляет заявку сюда (на ваш же домен), а скрипт
   уже с сервера шлёт письмо на почту. Плюс такого канала:
   он на том же домене, что и сайт, — блокировщики рекламы и
   провайдеры его не режут, в отличие от сторонних сервисов.

   Отправляет ТОЛЬКО на зашитый ниже адрес — использовать
   скрипт как спам-рассыльщик нельзя.

   Поддерживает два режима:
   · legacy — { message, _subject } (формы остальных страниц);
   · структурированный — form_id=noda_web_development с полями
     name / contact / format / description: сервер сам валидирует
     поля и собирает текст письма. Плюс honeypot (website),
     защита от повторов (_rid) и лёгкое ограничение частоты.
   ============================================================ */

/* ---- настройки ---- */
$TO   = 'noda_development@mail.ru';          // куда приходят заявки
$FROM = 'noreply@noda-development.ru';        // отправитель (адрес на вашем домене!)
$ALLOW_HOST = 'noda-development.ru';          // с какого домена принимаем

header('Content-Type: application/json; charset=utf-8');

/* только POST */
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  http_response_code(405);
  echo json_encode(['success' => false, 'error' => 'method']);
  exit;
}

/* мягкая защита: если браузер прислал Origin/Referer — он должен быть с нашего домена */
$src = '';
if (!empty($_SERVER['HTTP_ORIGIN']))       $src = $_SERVER['HTTP_ORIGIN'];
elseif (!empty($_SERVER['HTTP_REFERER']))  $src = $_SERVER['HTTP_REFERER'];
if ($src !== '' && strpos($src, $ALLOW_HOST) === false && strpos($src, 'localhost') === false) {
  http_response_code(403);
  echo json_encode(['success' => false, 'error' => 'origin']);
  exit;
}

/* тело запроса: JSON или обычная форма */
$raw  = file_get_contents('php://input');
$data = json_decode($raw, true);
if (!is_array($data)) { $data = $_POST; }

$formId = isset($data['form_id']) ? trim((string)$data['form_id']) : '';

/* honeypot: люди это поле не видят и не заполняют.
   Боту отвечаем «успехом», письмо не отправляем. */
if (!empty($data['website'])) {
  echo json_encode(['success' => true]);
  exit;
}

/* защита от повторной обработки одного запроса (двойной клик, ретрай):
   по клиентскому _rid держим короткий журнал; повтор — идемпотентный успех.
   Любая ошибка файловых операций не должна ломать приём заявки. */
$rid = isset($data['_rid']) ? preg_replace('/[^A-Za-z0-9._-]/', '', (string)$data['_rid']) : '';
if ($rid !== '' && strlen($rid) <= 64) {
  $ridFile = sys_get_temp_dir() . '/noda_lead_rids.json';
  $now = time();
  $rids = [];
  $j = @file_get_contents($ridFile);
  if ($j !== false) { $d = json_decode($j, true); if (is_array($d)) $rids = $d; }
  foreach ($rids as $k => $t) { if ($now - (int)$t > 600) unset($rids[$k]); }
  if (isset($rids[$rid])) {
    echo json_encode(['success' => true, 'dup' => true]);
    exit;
  }
  $rids[$rid] = $now;
  @file_put_contents($ridFile, json_encode($rids), LOCK_EX);
}

/* лёгкое ограничение частоты для структурированной формы: 5 заявок / 10 минут с IP */
if ($formId !== '') {
  $ip = isset($_SERVER['REMOTE_ADDR']) ? (string)$_SERVER['REMOTE_ADDR'] : '';
  if ($ip !== '') {
    $rlFile = sys_get_temp_dir() . '/noda_lead_rate.json';
    $now = time();
    $rl = [];
    $j = @file_get_contents($rlFile);
    if ($j !== false) { $d = json_decode($j, true); if (is_array($d)) $rl = $d; }
    $times = isset($rl[$ip]) && is_array($rl[$ip]) ? $rl[$ip] : [];
    $times = array_values(array_filter($times, function ($t) use ($now) { return $now - (int)$t < 600; }));
    if (count($times) >= 5) {
      http_response_code(429);
      echo json_encode(['success' => false, 'error' => 'rate']);
      exit;
    }
    $times[] = $now;
    $rl[$ip] = $times;
    foreach ($rl as $k => $ts) {
      $ts = array_values(array_filter((array)$ts, function ($t) use ($now) { return $now - (int)$t < 600; }));
      if (!$ts) unset($rl[$k]); else $rl[$k] = $ts;
    }
    @file_put_contents($rlFile, json_encode($rl), LOCK_EX);
  }
}

if ($formId === 'noda_ai_service') {
  /* структурированная форма страницы «Внедрение ИИ» */
  $name     = isset($data['name']) ? trim((string)$data['name']) : '';
  $contact  = isset($data['contact']) ? trim((string)$data['contact']) : '';
  $interest = isset($data['interest']) ? trim((string)$data['interest']) : '';
  $desc     = isset($data['description']) ? trim((string)$data['description']) : '';
  $page     = isset($data['page']) ? trim((string)$data['page']) : '';

  $allowedInterests = ['Ответы клиентам', 'Разбор документов', 'Действия в CRM', 'Нужен совет'];

  if ($contact === '' || mb_strlen($contact) > 120) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'contact']);
    exit;
  }
  if (mb_strlen($name) > 80 || mb_strlen($desc) > 3000 || mb_strlen($page) > 300) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'length']);
    exit;
  }
  if (!in_array($interest, $allowedInterests, true)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'interest']);
    exit;
  }

  $lines = ['Заявка с сайта NODA · Внедрение ИИ'];
  if ($name !== '')  $lines[] = 'Имя: ' . $name;
  $lines[] = 'Контакт: ' . $contact;
  $lines[] = 'Сценарий: ' . $interest;
  if ($desc !== '')  $lines[] = 'Задача: ' . $desc;
  $lines[] = 'Источник: Страница внедрения ИИ';
  if ($page !== '')  $lines[] = 'Страница: ' . $page;
  $lines[] = 'Получено: ' . date('Y-m-d H:i:s');

  $message = implode("\n", $lines);
  $subject = 'Заявка с сайта NODA · Внедрение ИИ';
} elseif ($formId === 'noda_web_development') {
  /* структурированная форма страницы «Сайты и приложения»:
     серверная валидация полей и сборка письма из них */
  $name    = isset($data['name']) ? trim((string)$data['name']) : '';
  $contact = isset($data['contact']) ? trim((string)$data['contact']) : '';
  $format  = isset($data['format']) ? trim((string)$data['format']) : '';
  $desc    = isset($data['description']) ? trim((string)$data['description']) : '';
  $page    = isset($data['page']) ? trim((string)$data['page']) : '';
  $utm     = isset($data['utm']) ? trim((string)$data['utm']) : '';

  $allowedFormats = ['Лендинг', 'Сайт компании', 'Веб-приложение', 'Нужен совет'];

  if ($contact === '' || mb_strlen($contact) > 120) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'contact']);
    exit;
  }
  if (mb_strlen($name) > 80 || mb_strlen($desc) > 3000 || mb_strlen($page) > 300 || mb_strlen($utm) > 500) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'length']);
    exit;
  }
  if (!in_array($format, $allowedFormats, true)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'format']);
    exit;
  }

  $lines = ['Заявка с сайта NODA · Сайты и приложения'];
  if ($name !== '')  $lines[] = 'Имя: ' . $name;
  $lines[] = 'Контакт: ' . $contact;
  $lines[] = 'Формат: ' . $format;
  if ($desc !== '')  $lines[] = 'Задача: ' . $desc;
  $lines[] = 'Форма: noda_web_development';
  if ($page !== '')  $lines[] = 'Страница: ' . $page;
  if ($utm !== '')   $lines[] = 'UTM: ' . $utm;
  $lines[] = 'Получено: ' . date('Y-m-d H:i:s');

  $message = implode("\n", $lines);
  $subject = 'Заявка с сайта NODA · Сайты и приложения';
} else {
  /* legacy-режим: формы остальных страниц */
  $message = isset($data['message']) ? trim((string)$data['message']) : '';
  $subject = isset($data['_subject']) ? trim((string)$data['_subject']) : 'Заявка с сайта NODA';

  if ($message === '' || mb_strlen($message) > 5000) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'empty']);
    exit;
  }
}

/* защита от инъекции заголовков: всё пользовательское уходит только в тело письма,
   в тему пускаем без переносов строк */
$subject = str_replace(["\r", "\n"], ' ', $subject);
$subjectEnc = '=?UTF-8?B?' . base64_encode($subject) . '?=';

$headers   = [];
$headers[] = 'MIME-Version: 1.0';
$headers[] = 'Content-Type: text/plain; charset=UTF-8';
$headers[] = 'Content-Transfer-Encoding: 8bit';
$headers[] = 'From: NODA <' . $FROM . '>';

$ok = @mail($TO, $subjectEnc, $message, implode("\r\n", $headers));

if ($ok) {
  echo json_encode(['success' => true]);
} else {
  http_response_code(500);
  echo json_encode(['success' => false, 'error' => 'mail']);
}
