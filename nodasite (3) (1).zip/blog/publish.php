<?php
/* ============================================================
   NODA · прямая публикация статей из конструктора.

   Конструктор шлёт сюда (на ваш же домен) готовую статью в JSON:
   HTML страницы, картинки (base64) и запись для списка блога.
   Скрипт пишет /blog/<slug>/index.html, кладёт картинки в ту же
   папку и обновляет /blog/articles.js — статья появляется на сайте
   в один клик, без ручной заливки.

   Защита: пароль (тот же, что вход в конструктор). В запросе идёт
   сам пароль, сервер сверяет его SHA-256 с зашитым отпечатком.
   Исходник PHP наружу не отдаётся, а по одному отпечатку пароль
   не восстановить, поэтому опубликовать может только тот, кто
   знает пароль.
   ============================================================ */

header('Content-Type: application/json; charset=utf-8');

/* SHA-256 пароля (тот же отпечаток, что в /custom/gate.js) */
$HASH       = 'affa59303972ae5f03d063df4a44413db0578fe87471f3ebe809ac020278f06d';
$ALLOW_HOST = 'noda-development.ru';
$BLOG_DIR   = __DIR__;               /* publish.php лежит в /blog/ */
$MAX_BODY   = 12 * 1024 * 1024;      /* 12 МБ на весь запрос */
$MAX_IMG    = 6  * 1024 * 1024;      /* 6 МБ на картинку */

function fail($code, $err) {
  http_response_code($code);
  echo json_encode(['ok' => false, 'error' => $err]);
  exit;
}

/* только POST */
if ($_SERVER['REQUEST_METHOD'] !== 'POST') fail(405, 'method');

/* мягкая проверка источника — как в mail.php */
$srcRef = '';
if (!empty($_SERVER['HTTP_ORIGIN']))      $srcRef = $_SERVER['HTTP_ORIGIN'];
elseif (!empty($_SERVER['HTTP_REFERER'])) $srcRef = $_SERVER['HTTP_REFERER'];
if ($srcRef !== '' && strpos($srcRef, $ALLOW_HOST) === false && strpos($srcRef, 'localhost') === false) {
  fail(403, 'origin');
}

$raw = file_get_contents('php://input');
if (strlen($raw) > $MAX_BODY) fail(413, 'too_big');
$data = json_decode($raw, true);
if (!is_array($data)) fail(400, 'json');

/* аутентификация: нужен исходный пароль, а не его отпечаток */
$pw = isset($data['pw']) ? (string)$data['pw'] : '';
if ($pw === '' || !hash_equals($HASH, hash('sha256', $pw))) fail(401, 'auth');

/* slug — только латиница/цифры/дефис */
$slug = isset($data['slug']) ? strtolower((string)$data['slug']) : '';
$slug = preg_replace('/[^a-z0-9-]/', '', $slug);
$slug = trim($slug, '-');
if ($slug === '' || strlen($slug) > 80) fail(400, 'slug');

/* HTML статьи */
$html = isset($data['html']) ? (string)$data['html'] : '';
if ($html === '' || stripos($html, '<html') === false) fail(400, 'html');

/* запись для articles.js */
$entry = (isset($data['entry']) && is_array($data['entry'])) ? $data['entry'] : null;
if (!$entry || empty($entry['title'])) fail(400, 'entry');
$entry['slug'] = $slug;   /* slug приводим к очищенному */

/* каталог статьи */
$dir = $BLOG_DIR . '/' . $slug;
if (!is_dir($dir) && !@mkdir($dir, 0755, true)) fail(500, 'mkdir');

/* картинки: [{name, data(base64 или data:URL)}] */
$imgs = (isset($data['images']) && is_array($data['images'])) ? $data['images'] : [];
foreach ($imgs as $im) {
  if (!isset($im['name'], $im['data'])) continue;
  $name = basename((string)$im['name']);
  if (!preg_match('/^[A-Za-z0-9._-]+\.(png|jpe?g|webp|gif|svg)$/i', $name)) fail(400, 'imgname');
  $b64 = (string)$im['data'];
  if (($p = strpos($b64, 'base64,')) !== false) $b64 = substr($b64, $p + 7);
  $bin = base64_decode($b64, true);
  if ($bin === false) fail(400, 'imgdata');
  if (strlen($bin) > $MAX_IMG) fail(413, 'imgbig');
  if (@file_put_contents($dir . '/' . $name, $bin) === false) fail(500, 'imgwrite');
}

/* сама страница */
if (@file_put_contents($dir . '/index.html', $html) === false) fail(500, 'htmlwrite');

/* обновить список статей: убрать прежнюю с тем же slug, новую — в начало */
$af   = $BLOG_DIR . '/articles.js';
$list = [];
if (is_file($af)) {
  $txt = file_get_contents($af);
  if (preg_match('/window\.NODA_BLOG\s*=\s*(\[.*\])\s*;/s', $txt, $m)) {
    $parsed = json_decode($m[1], true);
    if (is_array($parsed)) $list = $parsed;
  }
}
$list = array_values(array_filter($list, function ($a) use ($slug) {
  return !(isset($a['slug']) && $a['slug'] === $slug);
}));
array_unshift($list, $entry);

$json = json_encode($list, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
$out  = "/* NODA · Blog — список статей. Новые добавляйте в начало массива.\n" .
        "   Проще всего — через конструктор (адрес — в закладках владельца сайта). */\n" .
        'window.NODA_BLOG = ' . $json . ";\n";
if (@file_put_contents($af, $out) === false) fail(500, 'listwrite');

echo json_encode(['ok' => true, 'url' => '/blog/' . $slug . '/']);
